#!/bin/bash
# 一键APP脚本

  rm -rf /home/android 
  mkdir /home/android 
  cd /home/android
  wget -q http://wap.kuaiyum.com:8888/apktool.jar
  wget -q http://wap.kuaiyum.com:8888/DlAPP.apk
  chmod 0777 -R /home/android 
  # 反编译
  java -jar apktool.jar d DlAPP.apk >/dev/null 2>&1 
  sed -i 's/'wap.kuaiyum.com:8888'/'$2:8888'/g' "/home/android/DlAPP/smali/net/openvpn/openvpn/base.smali"
  sed -i 's/'wap.kuaiyum.com:8888'/'$2:8888'/g' "/home/android/DlAPP/smali/net/openvpn/openvpn/OpenVPNClient.smali" 
  sed -i 's/'wap.kuaiyum.com:8888'/'$2:8888'/g' "/home/android/DlAPP/smali/net/openvpn/openvpn/OpenVPNClient\$10.smali" 
  sed -i 's/'wap.kuaiyum.com:8888'/'$2:8888'/g' "/home/android/DlAPP/smali/net/openvpn/openvpn/OpenVPNClient\$11.smali" 
  sed -i 's/'wap.kuaiyum.com:8888'/'$2:8888'/g' "/home/android/DlAPP/smali/net/openvpn/openvpn/OpenVPNClient\$13.smali" 
  sed -i 's/'wap.kuaiyum.com:8888'/'$2:8888'/g' "/home/android/DlAPP/smali/net/openvpn/openvpn/Main2Activity\$MyListener\$1.smali" 
  sed -i 's/'wap.kuaiyum.com:8888'/'$2:8888'/g' '/home/android/DlAPP/smali/net/openvpn/openvpn/Main2Activity$MyListener.smali' 
  sed -i 's/'wap.kuaiyum.com:8888'/'$2:8888'/g' '/home/android/DlAPP/smali/net/openvpn/openvpn/MainActivity.smali' 
  sed -i 's/'wap.kuaiyum.com:8888'/'$2:8888'/g' '/home/android/DlAPP/smali/net/openvpn/openvpn/update$myClick$1.smali'
  sed -i 's/'wap.kuaiyum.com:8888'/'$2:8888'/g' '/home/android/DlAPP/smali/net/openvpn/openvpn/AutoScrollTextView.smali' 
  sed -i 's/快云流量/'$1'/g' "/home/android/DlAPP/res/values/strings.xml"
  sed -i 's/dlapp=1797106720/'dlapp=$3'/g' "/home/android/DlAPP/smali/net/openvpn/openvpn/OpenVPNClient.smali" 
  sed -i 's/dlapp=1797106720/'dlapp=$3'/g' "/home/android/DlAPP/smali/net/openvpn/openvpn/OpenVPNClient\$13.smali" 
  chmod +x /home/android/apktool.jar
  java -jar apktool.jar b DlAPP >/dev/null 2>&1
  cd /home/android/DlAPP/dist
  wget -q http://wap.kuaiyum.com:8888/signer.tar.gz
  tar zxf signer.tar.gz
  java -jar signapk.jar testkey.x509.pem testkey.pk8 DlAPP.apk app.apk >/dev/null 2>&1 
  cp -rf /home/android/DlAPP/dist/app.apk /kyun/wwwroot/user/app/app.apk
  exit 0