# 快云免流自动备份脚本
source /etc/openvpn/kyun.conf
mysqldump -u$Kyun_USER -p$Kyun_PASS $Kyun_NAME > /kyun/Backups/mysql_`date +%Y%m%d%H%M%S`_bak.sql
