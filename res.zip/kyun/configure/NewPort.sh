#!/bin/bash
# 添加新端口
  read has < <(ps -ef | grep "K666 -l $2 -d" | grep -v grep | awk '{print $2}') #检测端口PID是否已运行
  if [ -z "$has" ];then
       K666 -l $1 -d >/dev/null 2>&1
        iptables -A INPUT -p tcp -m tcp --dport $1 -j ACCEPT
	    service iptables save >/dev/null 2>&1
        systemctl restart iptables.service
	  echo 'ok'
  fi
 exit 0