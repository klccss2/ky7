<?php
/**
 *===================================
 * 项目：快云流控管理系统
 * 功能：批量在平台添加新账号
 * 作者：by 飞跃 
 * 时间：2017年11月4日 22点48分
 * 版权：归快云免流所有
 *===================================
 */
 
// 加载系统配置文件
require("../../Data/system.php");

if($is_login == 'ok'){
$db = db("openvpn");
?>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">


    <title>账号管理 - 批量添加账号</title>
    <meta name="keywords" content="">
    <meta name="description" content="">

    <link rel="shortcut icon" href="../favicon.ico"> <link href="../../assets/css/bootstrap.min.css?v=3.3.6" rel="stylesheet">
    <link href="../../assets/css/font-awesome.css" rel="stylesheet">
    <link href="../../assets/css/plugins/iCheck/custom.css" rel="stylesheet">
    <link href="../../assets/css/animate.css" rel="stylesheet">
    <link href="../../assets/css/style.css?v=4.1.0" rel="stylesheet">

</head>

<body class="gray-bg">
    <div class="wrapper wrapper-content animated fadeInRight">
    <div class="row">
                <div class="col-sm-12">
			<div class="ibox-mulu">
      <h3> &nbsp;&nbsp; <i class="fa fa-users fa-lg"></i> 账号管理 > 批量添加账号</h3>
              </div>
			  <br>		
<?php
if(isset($_POST['num'])){
echo '<div class="ibox"><div class="ibox-content"><h3>成功生成以下账号</h3>';
$num = daddslashes($_POST['num']);
$strlen = daddslashes($_POST['strlen']);
$tian = daddslashes($_POST['tian']);
$maxll = daddslashes($_POST['maxll']) * 1024 * 1024 * 1024;
$state = daddslashes($_POST['state']);
$endtime = time()+3600*24*daddslashes($_POST['tian']);
 for($i = 0 ; $i < $num; $i++){
   $user=getkm($strlen);
   $pass=getkm($strlen);
   if(!$db->where(array("iuser"=>$user))->find()){
      if($db->insert(array('iuser'=>$user,'pass'=>$pass,'maxll'=>$maxll,'i'=>$state,'starttime'=>time(),'endtime'=>$endtime,'tian'=>$tian)))	
          echo '账号：'.$user.'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;密码：'.$pass.'<br>';
      else 
          echo '<div class="box">抱歉，添加账号失败</div>';
   }else{
      echo '<div class="box">亲，该账号已存在</div>';
   }
 }
exit('<hr/><a href="./user_list.php" class="btn btn-success">返回账号列表</a></div></div>');
}
?>			
           <div class="ibox">
                  <div class="ibox-content">     
		             <form action="./padd_user.php" method="post" class="form-horizontal">
                            <div class="form-group has-success">
                                <label class="col-sm-2 control-label">账号数量</label>

                                <div class="col-sm-8">
                                    <input type="text" class="form-control" name="num">
                                </div>
                            </div>
							 <div class="hr-line-dashed"></div>
                           
                            <div class="form-group has-error">
                                <label class="col-sm-2 control-label">账号密码长度</label>
                             
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" name="strlen">
                                </div>
							  </div>
							  <div class="hr-line-dashed"></div>
                              <div class="form-group has-success">
                            <label class="col-sm-2 control-label">账号状态</label>
                             <div class="col-sm-8">
                                    <select class="form-control m-b" name="state">
                                        <option value="1">开通</option>
									    <option value="2">未激活</option>
                                    </select>
                                </div>
                            </div>
							 <div class="hr-line-dashed"></div>
                             <div class="form-group has-warning">
                                <label class="col-sm-2 control-label">使用天数</label>

                                <div class="col-sm-8">
                                    <input type="text" class="form-control" name="tian">
                                </div>
                            </div>
							
							 <div class="hr-line-dashed"></div>
                             <div class="form-group has-success">
                                <label class="col-sm-2 control-label">总流量（单位/G）</label>

                                <div class="col-sm-8">
                                    <input type="text" class="form-control" name="maxll">
                                </div>
                            </div>
                            <div class="hr-line-dashed"></div>
                            <div class="form-group">
                                <div class="col-sm-4 col-sm-offset-2">
                                    <button class="btn btn-primary" type="submit">保存内容</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
 </div>
</body>

</html>
<?php
}else{ 
    exit("<script language='javascript'>window.location.href='../Kyun/index.php';</script>");
}
?>
