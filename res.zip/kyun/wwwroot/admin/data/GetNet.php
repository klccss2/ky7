﻿<?php
/**
 *===================================
 * 项目：快云流控管理系统
 * 功能：WEB管理系统Js操作文件
 * 作者：by 飞跃 
 * 时间：2017年11月4日 22点48分
 * 版权：归快云免流所有
 *===================================
 */
 
// 加载系统配置文件
require("../../Data/system.php");

if($is_login == 'ok'){
   if( $_GET['act'] == 'net'){
       $net = file_get_contents("/kyun/configure/Network");
       $MB = round(($net/1024/1024), 2);
       die(json_encode(array('status'=>'success','net'=>$MB)));
   }elseif( $_GET['act'] == 'down'){
       $res = db("line")->where(array('id'=>$_GET['id']))->find();
       if(!$res){
          exit("<script>alert('亲，平台没有此线路！');history.go(-1);</script>");
       }
           $zs = db('ky_zs')->where(array())->find();
           $fwq = db('ky_fz')->where(array())->find();
           $fileName = $res['name'].'.ovpn';
           $name = iconv('UTF-8','GBK',$fileName);
           $content = preg_replace("/\[ip\]/is",$fwq["ipport"],$res['content']);
           $content = preg_replace("/\[C证书\]/is",$zs["ca"],$content);
           $content = preg_replace("/\[T证书\]/is",$zs["tls"],$content);
		   Header( "Content-type:  application/octet-stream "); 
           Header( "Accept-Ranges:  bytes "); 
           Header( "Accept-Length: " .filesize($name));
           header("Content-Disposition: attachment; filename=\"" . $name . "\"");
           echo html_decode($content);   
   }elseif( $_GET['act'] == 'xsu'){
      $u = $_POST['user'];
      $zhi = $_POST['zhi'];
      $xsu = exec("Kps xsu {$u} {$zhi}");
      if($xsu == 'ok'){
          die(json_encode(array('status'=>'success')));
      }else{
          die(json_encode(array('status'=>'erorr','msg'=>'操作失败，请骚后再试！')));
      }
   }elseif( $_GET['act'] == 'outline'){
      $u = $_GET['user'];
      $dk = $_GET['opdk'];
      $sha = exec("/bin/sha {$u} {$dk}");
      if($sha){
         die(json_encode(array('status'=>'success')));
      }else{
         die(json_encode(array('status'=>'erorr','msg'=>'操作失败，请骚后再试！')));
      }
   }elseif( $_GET['act'] == 'setweb'){
      $webdk = $_GET['webdk'];
      $web = exec("/kyun/configure/SetWeb.sh {$webdk}");
      if($web == 'ok'){ 
         die(json_encode(array('status'=>'success')));
      }else{
        die(json_encode(array('status'=>'erorr','msg'=>'操作失败，请骚后再试！')));
      }
   }elseif( $_GET['act'] == 'setxsu'){
      $limit = $_GET["limit"];
      $content = "default {$limit}
total 1000";
      $setxsu = file_put_contents("/etc/openvpn/bwlimitplugin.cnf",$content); 
      if($setxsu){  
         die(json_encode(array('status'=>'success')));
      }else{
         die(json_encode(array('status'=>'erorr','msg'=>'操作失败，请骚后再试！')));
      }
   }elseif( $_GET['act'] == 'adddk' ){
      $dk = $_GET['nesdk'];
      $NesPort = exec("/kyun/configure/NewPort.sh {$dk}");
      if($NesPort == 'ok'){ 
         die(json_encode(array('status'=>'success')));
      }else{
          die(json_encode(array('status'=>'erorr','msg'=>'操作失败，请骚后再试！')));
      }
   }elseif( $_GET['act'] == 'mysql' ){
      $mysql = exec('Kps mysql');
      if($mysql == 'ok'){ 
         die(json_encode(array('status'=>'success')));
      }else{
         die(json_encode(array('status'=>'erorr','msg'=>'操作失败，请骚后再试！')));
      }
   }elseif( $_GET['act'] == 'httpd' ){
      $httpd = exec('Kps httpd');
      if($httpd == 'ok'){ 
         die(json_encode(array('status'=>'success')));
      }else{
         die(json_encode(array('status'=>'erorr','msg'=>'操作失败，请骚后再试！')));
      }	
   }elseif( $_GET['act'] == 'vpn' ){
      $vpn = system('vpn');
      if($vpn){ 
         die(json_encode(array('status'=>'success')));
      }else{
         die(json_encode(array('status'=>'erorr','msg'=>'操作失败，请骚后再试！')));
      }	
   }elseif( $_GET['act'] == 'fhq' ){
      $fhq = exec('Kps fhq');
      if($fhq == 'ok'){ 
         die(json_encode(array('status'=>'success')));
      }else{
         die(json_encode(array('status'=>'erorr','msg'=>'操作失败，请骚后再试！')));
      }	
   }
}else{
   exit("<script>window.location.href='../Kyun/index.php';</script>");
}                 
?>