<?php
/**
 *===================================
 * 项目：快云流控管理系统
 * 功能：修改客户端配置信息
 * 作者：by 飞跃 
 * 时间：2017年11月4日 22点48分
 * 版权：归快云免流所有
 *===================================
 */
 
// 加载系统配置文件
require("../../Data/system.php");

if($is_login == 'ok'){
?>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">


    <title>高级管理 - 修改配置信息</title>
    <meta name="keywords" content="">
    <meta name="description" content="">

    <link rel="shortcut icon" href="../favicon.ico"> 
	<link href="../../assets/css/bootstrap.min.css?v=3.3.6" rel="stylesheet">
    <link href="../../assets/css/font-awesome.css" rel="stylesheet">
    <link href="../../assets/css/animate.css" rel="stylesheet">
    <link href="../../assets/css/style.css?v=4.1.0" rel="stylesheet">

</head>

<body class="gray-bg">
    <div class="wrapper wrapper-content animated fadeInRight">
        <div class="row">
            <div class="col-sm-12">
			<div class="ibox-mulu">
      <h3> &nbsp;&nbsp; <i class="fa fa-user-md fa-lg"></i> 高级管理 > 平台信息</h3>
              </div>
			  <br>	
<?php
if($_POST["name"]){	
$name = daddslashes($_POST["name"]);
$qq = daddslashes($_POST["qq"]);
$html = daddslashes($_POST["html"]);
$versionCode=daddslashes($_POST["versionCode"]);
$content=daddslashes($_POST["content"]);
$downurl=daddslashes($_POST["down_url"]);
$splash=daddslashes($_POST["splash"]);
$splashurl=daddslashes($_POST["splashurl"]);
$reg_time=daddslashes($_POST['reg_time']);
$reg_cash=daddslashes($_POST['reg_cash']);
$reg_mode=daddslashes($_POST['reg_mode']);
$dl_reg=daddslashes($_POST['dl_reg']);
$u_reg=daddslashes($_POST['u_reg']);
$spread_cash=daddslashes($_POST['spread_cash']);
  if(db("ky_cfg")->where(array('id'=>'1'))->update(array(
                      'logo'=>$_POST['logo'],
                      'logo2'=>$_POST['logo2'],
					  'name'=>$name,'qq'=>$qq,
					  'html'=>$html,
					  'versionCode'=>$versionCode,
					  'content'=>$content,
					  'down_url'=>$downurl,
					  'splash'=>$splash,
					  'reg_time'=>$reg_time,
					  'reg_cash'=>$reg_cash,
					  'reg_mode'=>$reg_mode,
					  'spread_cash'=>$spread_cash,
					  'dl_reg'=>$dl_reg,
					  'u_reg'=>$u_reg,
					  'splashurl'=>$splashurl))){ 
        echo Skip('修改平台信息',success);
   }else{
        echo Skip('修改平台信息',error);
  }
exit;
}
?>           <div class="ibox">
                <div class="ibox-content">
                 <form action="./kyun_cfg.php" method="post" class="form-horizontal m-t">
				  <div class="form-group has-success">
            	   <input type="hidden" name="my" value="kyun"/>
                    <label class="col-sm-2 control-label">平台名称</label>
				       <div class="col-sm-2"><input type="text" class="form-control" name="logo" value="<?php echo admin_copy(logo);?>"/></div>
                     	<label class="col-sm-2 control-label">Logo图片地址</label>
				          <div class="col-sm-4"><input type="text" class="form-control" name="logo2" value="<?php echo admin_copy('logo2');?>"/></div>
			               </div> 
						  <div class="hr-line-dashed"></div>
			          <div class="form-group has-warning">
			          <div class="col-sm-2"></div>
             	      <label class="col-sm-1 control-label">注册赠送流量(M)</label>
				      <div class="col-sm-1"><input type="text" class="form-control" name="reg_cash" value="<?php echo admin_copy('reg_cash');?>"/></div>
				    <div class="col-sm-1"></div>
				    <label class="col-sm-1 control-label">注册赠送天数</label>
				    <div class="col-sm-1"><input type="text" class="form-control" name="reg_time" value="<?php echo admin_copy('reg_time');?>"/></div>
				    <div class="col-sm-1"></div>
			    	  <label class="col-sm-1 control-label">推荐赠送流量(M)</label>
				        <div class="col-sm-1"><input type="text" class="form-control" name="spread_cash" value="<?php echo admin_copy('spread_cash');?>"/></div>
		                	 </div>
								<div class="hr-line-dashed"></div>
			              <div class="form-group has-success">
                      <label class="col-sm-2 control-label">代理注册</label>
                     <div class="col-sm-2">
				    <select name="dl_reg" class="form-control">
                <?php 
					if(admin_copy('dl_reg') == 'ok'){
						  echo '<option value="ok">开放代理注册</option><option value="no">关闭代理注册</option>';
					}else{
						  echo '<option value="no" >关闭代理注册</option><option value="ok">开放代理注册</option>';
					}                  ?>
              </select>
			  </div>
              <label class="col-sm-1 control-label">普通用户注册</label>
                <div class="col-sm-2">
				<select name="u_reg" class="form-control">
                <?php 
                  if(admin_copy('u_reg') == 'ok'){
                          echo '<option value="ok">开放用户注册</option><option value="no">关闭用户注册</option>';
                 }else{
			             echo '<option value="no" >关闭用户注册</option><option value="ok">开放用户注册</option>';
		         }                      ?>
              </select>
			  </div>
              <label class="col-sm-1 control-label">账号注册方式</label>
                 <div class="col-sm-2">
				 <select name="reg_mode" class="form-control">
                  <?php 
					if(admin_copy('reg_mode') == 'dx'){
						echo '<option value="dx">短信注册账号</option><option value="reg">普通注册账号</option>';
					}else{
						echo '<option value="reg">普通注册账号</option><option value="dx">短信注册账号</option>'; 
					}                    ?>
                 </select>
			         </div>
			             </div>
						    <div class="hr-line-dashed"></div>
						     <div class="form-group has-error">
                                <label class="col-sm-2 control-label">客服名字：</label>
                                <div class="col-sm-3">
                                    <input type="text" class="form-control" value="<?php echo admin_copy(name);?>" name="name" required="required"/>
                                </div>
								<label class="col-sm-2 control-label">客服QQ：</label>
                                <div class="col-sm-3">
                                    <input type="text" class="form-control" value="<?php echo admin_copy(qq);?>" name="qq" required="required"/>
                                </div>
                            </div>
							 <div class="hr-line-dashed"></div>
						    <div class="form-group has-success"> 
                                <label class="col-sm-2 control-label">客服内容：</label>
                                 <div class="col-sm-8">
                                   <textarea class="form-control" rows="3" name="html"><?php echo admin_copy(html);?></textarea>
                                 </div>
								</div>
								<div class="hr-line-dashed"></div>
								 <div class="form-group has-warning">
								 <label class="col-sm-2 control-label">启动图</label>
								   <div class="col-sm-2">
                                    <select class="form-control m-b" name="splash">
									<?php
									if(admin_copy("splash") == 'yes'){
									   echo '<option value="yes">启用</option>
									         <option value="no">关闭</option>';
									}else{
									   echo '<option value="no">关闭</option>
									        <option value="yes">启用</option>';
									}                                  ?>
                                    </select>
                                </div>
								<label class="col-sm-2 control-label">启动图地址</label>
                                <div class="col-sm-4">
                                    <input type="text" class="form-control" value="<?php echo admin_copy(splashurl);?>" name="splashurl" required="required"/>
                                </div>
                            </div>
							 <div class="hr-line-dashed"></div>
						  <div class="form-group has-success">
                                <label class="col-sm-2 control-label">版本号</label>
                                <div class="col-sm-2">
                                    <input type="text" class="form-control" value="<?php echo admin_copy(versionCode);?>" name="versionCode" required="required"/>
                                </div>
								<label class="col-sm-2 control-label">软件下载地址</label>
                                <div class="col-sm-4">
                                    <input type="text" class="form-control" value="<?php echo admin_copy(down_url);?>" name="down_url" required="required"/>
                                </div>
                            </div>
							 <div class="hr-line-dashed"></div>
						    <div class="form-group has-error"> 
                                <label class="col-sm-2 control-label">更新提示内容</label>
                                 <div class="col-sm-8">
                                   <textarea class="form-control" rows="4" name="content"><?php echo admin_copy("content");?></textarea>
                                 </div>
								</div>
							  <div class="hr-line-dashed"></div>
                            <div class="form-group">
                                <div class="col-sm-4 col-sm-offset-2"> 
                                    <button class="btn btn-primary" type="submit">保存内容</button>
                                </div>
                            </div>
                        </form>					
                    </div>
                </div>
            </div>
        </div>

    </div>

</body>

</html>
<?php
}else{ 
    exit("<script language='javascript'>window.location.href='../Kyun/index.php';</script>");
}
?>