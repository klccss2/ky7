<?php
/**
 *===================================
 * 项目：快云流控管理系统
 * 功能：修改账号流量配置信息
 * 作者：by 飞跃 
 * 时间：2017年11月4日 22点48分
 * 版权：归快云免流所有
 *===================================
 */
 
// 加载系统配置文件
require("../../Data/system.php");

if($is_login == 'ok'){
$db = db("openvpn");
$row = $db->where(array("iuser"=>$_GET['user']))->find();
if(!$row){
  exit("<script>alert('亲，平台找不到此用户！');history.go(-1);</script>");
}
if($row["i"] == "1" ){
	$zhtai='1';
	$zhtai2="开通";
	$zhtai3='2';
	$zhtai4="未激活";
	$zhtai5='0';
	$zhtai6="禁用";
}elseif($row['i'] == "2"){
	$zhtai='2';
	$zhtai2='未激活';
	$zhtai3='1';
	$zhtai4="开通";
	$zhtai5='0';
	$zhtai6="禁用";
}elseif($row['i'] == "0"){
	$zhtai='0';
	$zhtai2='禁用';
	$zhtai3='2';
	$zhtai4="未激活";
	$zhtai5='1';
	$zhtai6="开通";
}
?>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">


    <title>账号管理 - 修改账号</title>
    <meta name="keywords" content="">
    <meta name="description" content="">

    <link rel="shortcut icon" href="../favicon.ico">
	<link href="../../assets/css/bootstrap.min.css?v=3.3.6" rel="stylesheet">
    <link href="../../assets/css/font-awesome.css" rel="stylesheet">
    <link href="../../assets/css/animate.css" rel="stylesheet">
    <link href="../../assets/css/style.css?v=4.1.0" rel="stylesheet"><script src="../../assets/js/amcharts.js"></script>
    <script src="../../assets/js/pie.js"></script>
    <link rel="stylesheet" href="../../assets/css/export.css" type="text/css" media="all" />
    <script src="../../assets/js/light.js"></script>
<style>
.User{
  width: 100%;
  height: 380px;
}											
</style>
</head>

<body class="gray-bg">
    <div class="wrapper wrapper-content animated fadeInRight">
    <div class="row">
                <div class="col-sm-12">
			<div class="ibox-mulu">
      <h3> &nbsp;&nbsp; <i class="fa fa-users fa-lg"></i> 账号管理 > 修改账号</h3>
              </div>
			  <br>		
<?php
if($_POST['type']=="update"){
$pass = daddslashes($_POST['pass']);
$maxll = daddslashes($_POST['maxll'])*1024*1024*1024;
$state = daddslashes($_POST['state']);
$tian = daddslashes($_POST['tian']);
$endtime = time()+3600*24*daddslashes($_POST['tian']);
   if($db->where(array("iuser"=>$_GET['user']))->update(array('pass'=>$pass,'isent'=>'0','irecv'=>'0','maxll'=>$maxll,'i'=>$state,'endtime'=>$endtime,'tian'=>$tian))){
       echo Skip('修改账号【'.$row['iuser'].'】',success);
   }else{
       echo Skip('修改账号【'.$row['iuser'].'】',error);
  }
 exit;
}?>
       <div class="row">
			<div class="col-sm-7">
	          <div class="ibox">
                  <div class="ibox-content">
                    <form action="./uesr_set.php?user=<?php echo $row['iuser'];?>" method="post" class="form-horizontal">
						  <input type="hidden" name="type" value="update" />
						  <div class="form-group has-success">
                                <label class="col-sm-2 control-label">账号</label>

                                <div class="col-sm-10">
                                    <input type="text" class="form-control" value="<?php echo $row['iuser']?>" disabled="disabled">
                                </div>
                            </div>
                            <div class="hr-line-dashed"></div>
                          <div class="form-group has-success">
                                <label class="col-sm-2 control-label">密码</label>

                                <div class="col-sm-10">
                                    <input type="text" class="form-control" value="<?php echo $row['pass']?>" name="pass">
                                </div>
                            </div>
                            <div class="hr-line-dashed"></div>
                            <div class="form-group has-warning">
                                <label class="col-sm-2 control-label">账号状态</label>

                                <div class="col-sm-10">
                                 <select class="form-control m-b" name="state">
                                     <option value="<?php echo $zhtai?>"><?php echo $zhtai2?></option>
									 <option value="<?php echo $zhtai3?>"><?php echo $zhtai4?></option>
									 <option value="<?php echo $zhtai5?>"><?php echo $zhtai6?></option>
                                    </select>
                                </div>
                            </div>
							 <div class="hr-line-dashed"></div>
                             <div class="form-group has-success">
                                <label class="col-sm-2 control-label">使用天数</label>

                                <div class="col-sm-10">
                                    <input type="text" value="<?php echo $row['tian']?>" class="form-control" name="tian">
                                </div>
                            </div>
                            <div class="hr-line-dashed"></div>
							 <div class="form-group has-error">
                                <label class="col-sm-2 control-label">总流量(单位/G)</label>

                                <div class="col-sm-10">
                                    <input type="text" value="<?php echo round($row['maxll']/1024/1024/1024)?>" class="form-control" name="maxll">
                                </div>
                            </div>
                            <div class="hr-line-dashed"></div>
                            <div class="form-group">
                                <div class="col-sm-4 col-sm-offset-2">
                                    <button class="btn btn-primary" type="submit">保存内容</button>
								</form>								
								</div>
                            </div>
                        </div>
                    </div>
				 </div>
	          <div class="col-sm-5">
                 <div class="ibox">
                    <div class="ibox-content">
                  <div class="row">
			   <h4> &nbsp; 用户<?php echo $row['iuser'];?>流量使用情况<h4>
            <div class="User" id="User_ALL"></div>																																																																																																																																																
		</div>
		  </div>
            </div>
            </div>
            </div>
        </div>
    </div>
 </div>
</body>
<script>
var chart = AmCharts.makeChart( "User_ALL", {
  "type": "pie",
  "theme": "light",
  "dataProvider": [ {
    "状态": "发送流量",
    "MB": <?php echo round($row["isent"]/1024/1024);?>
  },{
    "状态": "接受流量",
    "MB": <?php echo round($row["irecv"]/1024/1024);?>
  }, {
    "状态": "剩余流量",
    "MB": <?php $ybf = round($row["maxll"]/1024/1024);
	             if($ybf == '0'){
							$ybf = 1;
				 }      
                 echo $ybf;				?>
  }],
  "valueField": "MB",
  "titleField": "状态",
  "outlineAlpha": 0.4,
  "depth3D": 15,
  "balloonText": "[[title]]<br><span style='font-size:14px'><b>[[value]]</b> ([[percents]]%)</span>",
  "angle": 30,
  "export": {
    "enabled": true
  }
} );
</script>
</html>
<?php
}else{ 
    exit("<script language='javascript'>window.location.href='../Kyun/index.php';</script>");
}
?>