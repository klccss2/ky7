<?php
/**
 *===================================
 * 项目：快云流控管理系统
 * 功能：修改平台线路配置文件
 * 作者：by 飞跃 
 * 时间：2017年11月4日 22点48分
 * 版权：归快云免流所有
 *===================================
 */
 
// 加载系统配置文件
require("../../Data/system.php");

if($is_login == 'ok'){
$db = db("line");
$res = $db->where(array('id'=>$_GET['id']))->find();
if(!$res){
  exit("<script>alert('亲，平台没有此线路！');history.go(-1);</script>");
}
?>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">


    <title>线路管理 - 编辑线路</title>
    <meta name="keywords" content="">
    <meta name="description" content="">

    <link rel="shortcut icon" href="../favicon.ico">
	<link href="../../assets/css/bootstrap.min.css?v=3.3.6" rel="stylesheet">
    <link href="../../assets/css/font-awesome.css" rel="stylesheet">
    <link href="../../assets/css/animate.css" rel="stylesheet">
    <link href="../../assets/css/style.css" rel="stylesheet">

</head>

<body class="gray-bg">
    <div class="wrapper wrapper-content animated fadeInRight">
    <div class="row">
            <div class="col-sm-12">
				<div class="ibox-mulu">
             <h4> &nbsp;&nbsp; <i class="fa fa-shekel fa-lg"></i> 线路管理 > 修改线路</h4>
              </div>
			  <br>
<?php
if ($_POST['content']) {
$name = daddslashes($_POST['name']);
$label = daddslashes($_POST['sm']);
$group = daddslashes($_POST['group']);
  if($db->where(array('id'=>$_GET['id']))->update(array('name'=>$name,'content'=>$_POST['content'],'type'=>date("Y-m-d"),'group'=>$group,'label'=>$label))){				 
      echo Skip('修改线路【'.$name.'】',success);
  }else{
      echo Skip('修改线路【'.$name.'】',error);
  }
exit;
}?>       <div class="ibox">
                   <div class="ibox-content">
                  <form action="./set_line.php?id=<?=$res['id'];?>" method="post" class="form-horizontal">
                            <div class="form-group has-success">
                                <label class="col-sm-2 control-label">线路名称</label>

                                <div class="col-sm-10">
                                    <input type="text" class="form-control" value="<?php echo $res['name'];?>" name="name">
                                </div>
                            </div>
							 <div class="hr-line-dashed"></div>
                             <div class="form-group has-error">
                                <label class="col-sm-2 control-label">线路说明</label>

                                <div class="col-sm-10">
                                   <input type="text" class="form-control" value="<?php echo $res['label'];?>" name="sm">
                                </div>
                            </div>
							
							 <div class="hr-line-dashed"></div>
                            <div class="form-group has-warning">
                                <label class="col-sm-2 control-label">运营商选择：</label>
                                <div class="col-sm-10">
                                    <select class="form-control m-b" name="group">
<?php
		$line_grop = db('line_grop')->where(array())->order('id ASC')->select();
		foreach($line_grop as $vo){
			 $p = "";
			 if($vo["id"] == $res['group']){
					$p = 'selected';
				}
				echo '<option value="'.$vo["id"].'" '.$p.'>'.$vo["name"].'</option>';
				}	                      ?>
                                    </select>
                                </div>
                            </div>
                            <div class="hr-line-dashed"></div>
							<div class="form-group has-success">
                                 <label class="col-sm-2 control-label">免流代码：</label>
                                 <div class="col-sm-10">
                                   <textarea class="form-control" rows="10" name="content"><?php echo $res['content'];?></textarea>
                                 </div>
                            </div>
                            <div class="hr-line-dashed"></div>
                            <div class="form-group">
                                <div class="col-sm-4 col-sm-offset-2">
                                    <button class="btn btn-primary" type="submit">保存内容</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
  </div>		
</body>

</html>
<?php
}else{ 
    exit("<script language='javascript'>window.location.href='../Kyun/index.php';</script>");
}
?>