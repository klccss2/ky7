<?php
/**
 *===================================
 * 项目：快云流控管理系统
 * 功能：上次的生成卡密列表
 * 作者：by 飞跃 
 * 时间：2017年11月4日 22点48分
 * 版权：归快云免流所有
 *===================================
 */
 
// 加载系统配置文件
require("../../Data/system.php");

if($is_login == 'ok'){
?>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">


    <title>实时监控 - 监控日志</title>
    <meta name="keywords" content="">
    <meta name="description" content="">

    <link rel="shortcut icon" href="../favicon.ico"> 
	<link href="../../assets/css/bootstrap.min.css?v=3.3.6" rel="stylesheet">
    <link href="../../assets/css/font-awesome.css" rel="stylesheet">

    <link href="../../assets/css/animate.css" rel="stylesheet">
    <link href="../../assets/css/style.css?v=4.1.0" rel="stylesheet">

</head>

<body class="gray-bg">

<div class="wrapper wrapper-content animated fadeInUp">
<div class="row">
<div class="col-sm-12">
			<div class="ibox-mulu">
      <h3> &nbsp;&nbsp; <i class="fa fa-recycle fa-lg"></i> 实时监控 > 监控日志</h3>
              </div>
			  <br>
<?php
echo '<div class="ibox"><div class="ibox-content">';
$jk = nl2br(file_get_contents("/kyun/configure/jiankong.log"));
echo $jk;
?>
    </div>         
              </div>
			  </div>
		 </div>
			  </div>
    </body>
</html>
<?php
}else{ 
    exit("<script language='javascript'>window.location.href='../Kyun/index.php';</script>");
}
?>