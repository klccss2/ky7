<?php
/**
 *===================================
 * 项目：快云流控管理系统
 * 功能：修改服务节点配置信息
 * 作者：by 飞跃 
 * 时间：2017年11月4日 22点48分
 * 版权：归快云免流所有
 *===================================
 */
 
// 加载系统配置文件
require("../../Data/system.php");

if($is_login == 'ok'){
$db = db("ky_fz");
$row = $db->where(array('id'=>$_GET['id']))->find();
if(!$row){
exit("<script>alert('亲，没有这个节点！');history.go(-1);</script>");
}
?>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">


    <title>负载集群管理 - 修改节点</title>
    <meta name="keywords" content="">
    <meta name="description" content="">

    <link rel="shortcut icon" href="../favicon.ico"> 
	<link href="../../assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="../../assets/css/font-awesome.css" rel="stylesheet">
    <link href="../../assets/css/animate.css" rel="stylesheet">
    <link href="../../assets/css/style.css" rel="stylesheet">

</head>

<body class="gray-bg">
    <div class="wrapper wrapper-content animated fadeInRight">
        <div class="row">
               <div class="col-sm-12">
			<div class="ibox-mulu">
      <h3> &nbsp;&nbsp; <i class="fa fa-sitemap fa-lg"></i> 负载集群管理 > 修改节点</h3>
              </div>
			  <br>	
<?php
if($_POST['name']){
$name = daddslashes($_POST['name']);
$ipport = daddslashes($_POST['ipport']);
$type = daddslashes($_POST['type']);
$maximum = daddslashes($_POST['maximum']);
$order = daddslashes($_POST['order']);
  if($db->where(array("id"=>$_GET['id']))->update(array('name'=>$name,'ipport'=>$ipport,'type'=>$type,'maximum'=>$maximum,'order'=>$order))){				 
      echo Skip('修改节点【'.$name.'】',success);
  }else{
      echo Skip('修改节点【'.$name.'】',error);
  }
exit;
}?>	
                 <div class="ibox">
					<div class="ibox-content">
					  <form action="./note_set.php?id=<?=$row['id']?>" class="form-horizontal m-t" method="post">
						    <div class="form-group has-error"> 
                                <label class="col-sm-3 control-label">节点名称</label>
                                <div class="col-sm-8">
                                    <input id="firstname" name="name" value="<?php echo $row['name']?>" class="form-control" type="text">
                                 </div>
                            </div>
							 <div class="hr-line-dashed"></div>
							 
							 <div class="form-group has-success">
                                <label class="col-sm-3 control-label">节点地址</label>
                                <div class="col-sm-8">
                                    <input id="firstname" name="ipport" value="<?php echo $row['ipport']?>"class="form-control" type="text">
                                </div>
                            </div>
							 <div class="hr-line-dashed"></div>
							 
							 <div class="form-group has-warning">
                                <label class="col-sm-3 control-label">满载人数</label>
                                <div class="col-sm-8">
                                    <input name="maximum" value="<?php echo $row['maximum']?>" class="form-control" type="text">
                                </div>
							  </div>
							   <div class="hr-line-dashed"></div>
							 
							 <div class="form-group has-success">
                                <label class="col-sm-3 control-label">排序列表</label>
                                <div class="col-sm-8">
                                    <input name="order" value="<?php echo $row['order']?>" class="form-control" type="text">
                                </div>
							  </div>
							 <div class="hr-line-dashed"></div>
							 <div class="form-group has-error">
                                <label class="col-sm-3 control-label">节点描述</label>
                                <div class="col-sm-8">
                                    <input id="firstname" name="type" value="<?php echo $row['type']?>" class="form-control" type="text">
                                </div>
							  </div>
							 <div class="hr-line-dashed"></div>
                            <div class="form-group">
                                <div class="col-sm-8 col-sm-offset-3">
                                    <button class="btn btn-primary" type="submit">保存内容</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

    </div>

</body>

</html>
<?php
}else{ 
    exit("<script language='javascript'>window.location.href='../Kyun/index.php';</script>");
}
?>