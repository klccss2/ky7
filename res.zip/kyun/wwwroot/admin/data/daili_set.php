<?php
/**
 *===================================
 * 项目：快云流控管理系统
 * 功能：修改平台代理配置信息
 * 作者：by 飞跃 
 * 时间：2017年11月4日 22点48分
 * 版权：归快云免流所有
 *===================================
 */
 
// 加载系统配置文件
require("../../Data/system.php");

if($is_login == 'ok'){
$db = db("ky_dl");
$row = $db->where(array("user"=>$_GET['user']))->find();
if(!$row){
  exit("<script>alert('亲，平台找不到此代理！');history.go(-1);</script>");
}
?>	
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">


    <title>代理管理 - 修改代理</title>
    <meta name="keywords" content="">
    <meta name="description" content="">

    <link rel="shortcut icon" href="../favicon.ico"> 
	<link href="../../assets/css/bootstrap.min.css?v=3.3.6" rel="stylesheet">
    <link href="../../assets/css/font-awesome.css" rel="stylesheet">
    <link href="../../assets/css/animate.css" rel="stylesheet">
    <link href="../../assets/css/style.css?v=4.1.0" rel="stylesheet">

</head>

<body class="gray-bg">
    <div class="wrapper wrapper-content animated fadeInRight">
        <div class="row">
            <div class="col-sm-12">
			<div class="ibox-mulu">
      <h3> &nbsp;&nbsp; <i class="fa fa-cube fa-lg"></i> 代理管理 > 修改代理</h3>
              </div>
			  <br>				
<?php
if($_POST['pass']){
$user = daddslashes($_GET['user']);
$pass = daddslashes($_POST['pass']);
$qq = daddslashes($_POST['qq']);
$rebate = daddslashes($_POST['rebate']);
$status = daddslashes($_POST['status']);
$money = daddslashes($_POST['money']);
$html = daddslashes($_POST['html']);
$endtime = time()+3600*24*daddslashes($_POST['tian']);
 if($db->where(array('user'=>$user))->update(array('pass'=>$pass,'qq'=>$qq,'html'=>$html,'rebate'=>$rebate,'status'=>$status,'money'=>$money,'endtime'=>$endtime))){					 
      echo Skip('修改代理【'.$user.'】',success);
  }else{
      echo Skip('修改代理【'.$user.'】',error);
  }
exit;
}	?>
        	<div class="ibox">
                 <div class="ibox-content">		
                        <form action="./daili_set.php?user=<?=$row['user']?>" method="post" class="form-horizontal">
                            <div class="form-group has-success">
                                <label class="col-sm-2 control-label">账号</label>

                                <div class="col-sm-8">
                                    <input type="text" class="form-control" name="user" value="<?php echo $row['user']?>" disabled="disabled">
                                </div>
                            </div>
							 <div class="hr-line-dashed"></div>
                           
                            <div class="form-group has-error">
                                <label class="col-sm-2 control-label">密码</label>

                                <div class="col-sm-8">
                                    <input type="text" class="form-control" name="pass" value="<?php echo $row['pass']?>">
                                </div>
                            </div>
                            <div class="hr-line-dashed"></div>
                            <div class="form-group has-success">
                                <label class="col-sm-3 control-label">代理拿货折扣（单位/ %）</label>

                                <div class="col-sm-2">
                                    <input type="text" class="form-control" value="<?php echo $row['rebate']?>" name="rebate">
                                </div>
                                <label class="col-sm-2 control-label">联系QQ</label>

                                <div class="col-sm-3">
                                    <input type="text" class="form-control" name="qq" value="<?php echo $row['qq']?>">
                                </div>
                            </div>
                            <div class="hr-line-dashed"></div>
                            <div class="form-group has-warning">
                                <label class="col-sm-2 control-label">账号状态</label>

                                <div class="col-sm-2">
                                    <select class="form-control m-b" name="status">
									    <option value="ok">开通账号</option>
                                        <option value="no">禁用账号</option>
                                    </select>
                                </div>
                                <label class="col-sm-1 control-label">余额(元)</label>

                                <div class="col-sm-2">
                                    <input type="text" class="form-control" name="money" value="<?php echo $row['money']?>">
                                </div>
								<label class="col-sm-1 control-label">有效天数</label>

                                <div class="col-sm-2">
                                    <input type="text" class="form-control" name="tian" value="<?php echo round(($row['endtime'] - time())/86400);?>">
                                </div>
                            </div>
							 <div class="hr-line-dashed"></div>
						    <div class="form-group has-success"> 
                                <label class="col-sm-2 control-label">客服内容</label>
                                 <div class="col-sm-8">
                                   <textarea class="form-control" rows="6" name="html"><?php echo $row['html']?></textarea>
                                 </div>
								</div>
                            <div class="hr-line-dashed"></div>
                            <div class="form-group">
                                <div class="col-sm-6 col-sm-offset-2">
                                    <button class="btn btn-primary" type="submit">保存内容</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>
<?php
}else{
   exit("<script>window.location.href='../Kyun/index.php';</script>");
}                 
?>