<?php
/**
 *===================================
 * 项目：快云流控管理系统
 * 功能：添加一条新线路文件
 * 作者：by 飞跃 
 * 时间：2017年11月4日 22点48分
 * 版权：归快云免流所有
 *===================================
 */
 
// 加载系统配置文件
require("../../Data/system.php");

if($is_login == 'ok'){
$db = db("line");
?>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">


    <title>线路管理 - 添加线路</title>
    <meta name="keywords" content="">
    <meta name="description" content="">

    <link rel="shortcut icon" href="../favicon.ico"> 
	<link href="../../assets/css/bootstrap.min.css?v=3.3.6" rel="stylesheet">
    <link href="../../assets/css/font-awesome.css" rel="stylesheet">
	<link href="../../assets/css/animate.css" rel="stylesheet">
    <link href="../../assets/css/style.css" rel="stylesheet">

</head>

<body class="gray-bg">
    <div class="wrapper wrapper-content animated fadeInRight">
    <div class="row">
            <div class="col-sm-12">
	<div class="ibox-mulu">
             <h4> &nbsp;&nbsp; <i class="fa fa-shekel fa-lg"></i> 线路管理 > 添加线路</h4>
              </div>
			  <br>
<?php
if ($_POST['content']) {
$name = daddslashes($_POST['name']);
$type = date("Y-m-d");
$label = daddslashes($_POST['sm']);
$group = daddslashes($_POST['group']);
$line = array(
'# 快云云免配置',
'# 本文件由系统生成',
'setenv IV_GUI_VER "lyiqk.cn"',
'machine-readable-output',
'client',
'dev tun',
'proto '.$_POST['xieyi'],
'connect-retry-max 5',
'connect-retry 5',
'resolv-retry 60',
'########免流代码########',
$_POST['content'],
'########免流代码########',
'resolv-retry infinite',
'nobind',
'persist-key',
'persist-tun',
'## 证书',
'<ca>',
'[C证书]',
'</ca>',
'key-direction 1',
'<tls-auth>',
'[T证书]',
'</tls-auth>',
'auth-user-pass',
'ns-cert-type server',
'comp-lzo',
'verb 3');
$content = implode("\n",$line);
if($db->insert(array('name'=>$name,'content'=>$content,'type'=>$type,'group'=>$group,'show'=>'1','label'=>$label,'time'=>time()))){ 
  echo Skip('添加线路【'.$name.'】',success);
}else{
  echo Skip('添加线路【'.$name.'】',error);
}
 exit;
}?>    <div class="ibox">
               <div class="ibox-content">
                  <form action="./add_line.php" method="post" class="form-horizontal">
                            <div class="form-group has-success">
                                <label class="col-sm-2 control-label">线路名称</label>

                                <div class="col-sm-8">
                                    <input type="text" class="form-control" name="name" required="required"/>
                                </div>
                            </div>
							 <div class="hr-line-dashed"></div>
                             <div class="form-group has-error">
                                <label class="col-sm-2 control-label">线路说明</label>

                                <div class="col-sm-8">
                                   <input type="text" class="form-control" name="sm">
                                </div>
                            </div>
							
							 <div class="hr-line-dashed"></div>
                            <div class="form-group has-warning">
                                <label class="col-sm-2 control-label">运营商选择</label>
                                <div class="col-sm-3">
                                    <select class="form-control m-b" name="group">
                                  <?php
		                            $line_grop = db('line_grop')->where(array())->order('id ASC')->select();
		                            foreach($line_grop as $vo){
				                         echo '<option value="'.$vo["id"].'">'.$vo["name"].'</option>';
	                            	}		                 ?>
                                    </select>
                                </div>
							 <label class="col-sm-2 control-label">线路协议</label>
								   <div class="col-sm-3 control-label">
                                    <select class="form-control m-b" name="xieyi">
									<option value="tcp">TCP</option>
									<option value="udp">UDP</option>
                                    </select>
                                </div>
                            </div>
                            <div class="hr-line-dashed"></div>
							<div class="form-group has-success">
                                 <label class="col-sm-2 control-label">免流代码</label>
                                 <div class="col-sm-8">
                                   <textarea class="form-control" placeholder="只要输入免流代码，IP请换成 [ip]" rows="10" name="content"></textarea>
                                 </div>
                            </div>
                            <div class="hr-line-dashed"></div>
                            <div class="form-group">
                                <div class="col-sm-4 col-sm-offset-2"> 
                                    <button class="btn btn-primary" type="submit">保存内容</button>
                                </div>
                            </div>
                        </form>
                    </div>
            </div>
        </div>
    </div>	
  </div>
</body>

</html>
<?php
}else{
	exit("<script language='javascript'>window.location.href='../Kyun/index.php';</script>");
} 	
?>