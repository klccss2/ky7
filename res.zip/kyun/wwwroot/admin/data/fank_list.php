<?php
/**
 *===================================
 * 项目：快云流控管理系统
 * 功能：显示用户线路反馈情况
 * 作者：by 飞跃 
 * 时间：2017年11月4日 22点48分
 * 版权：归快云免流所有
 *===================================
 */
 
// 加载系统配置文件
require("../../Data/system.php");

if($is_login == 'ok'){
$db = db("ky_fk");
?>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">


    <title>线路管理 - 用户反馈</title>
    <meta name="keywords" content="">
    <meta name="description" content="">

    <link rel="shortcut icon" href="../favicon.ico"> 
	<link href="../../assets/css/bootstrap.min.css?v=3.3.6" rel="stylesheet">
    <link href="../../assets/css/font-awesome.css" rel="stylesheet">

    <link href="../../assets/css/animate.css" rel="stylesheet">
    <link href="../../assets/css/style.css?v=4.1.0" rel="stylesheet">

</head>

<body class="gray-bg">

<div class="wrapper wrapper-content animated fadeInUp">
<div class="row">
<div class="col-sm-12">
	<div class="ibox-mulu">
             <h4> &nbsp;&nbsp; <i class="fa fa-shekel fa-lg"></i> 线路管理 > 反馈列表</h4>
              </div>
			  <br>
<?php
if($_GET['my'] == 'del'){
  if($db->where(array('id'=>$_GET['id']))->delete()){
       echo Skip('删除反馈',success);
   }else{
	   echo Skip('删除反馈',error);
   }
 exit;
}
$numrows = $db->where(array())->getnums();
echo '<div class="ibox"><div class="ibox-content"><form>
<button type="submit" class="btn btn-primary">反馈情况</button> &nbsp;<a href="#" class="btn btn-info">平台共有 <b>'.$numrows.'</b> 条反馈</a></form>';
?>
     <div class="table-responsive">
        <table class="table table-bordered table-hover">
          <thead><tr><th class="text-center">ID</th><th class="text-center">线路名称</th><th class="text-center">用户账号</th><th class="text-center">运营商</th><th class="text-center">网速</th><th class="text-center">用户地区</th><th class="text-center">反馈时间</th><th class="text-center">操作</th></tr></thead>
           <tbody>
<?php
$pagesize=30;
$pages=intval($numrows/$pagesize);
if ($numrows%$pagesize)
{
 $pages++;
 }
if (isset($_GET['page'])){
$page=intval($_GET['page']);
}else{
$page=1;
}
$offset=$pagesize*($page - 1);
$fank_list = $db->where(array())->order('id desc')->limit($offset,$pagesize)->select();
foreach($fank_list as $res){
$row = db("line")->where(array('id'=>$res['lid']))->find();
$rw = db("line_grop")->where(array('id'=>$row['group']))->find();
if($res["wang"] == "1" ){
   $wang='<span class="label label-warning">有 限 速</span>';
}elseif($res["wang"] == "2" ){
   $wang='<span class="label label-info">不 限 速</span>';
}elseif($res["wang"] == "3" ){
   $wang='<span class="label label-primary">非 常 快</span>';
}
?>
<tr>
<td class="text-center"><?=$res['id']?></td>
<td class="text-center"><?=$row['name']?></td>
<td class="text-center"><?=$res['user']?></td>
<td class="text-center"><?=$rw["name"];?></td>
<td class="text-center"><?php echo $wang;?></td>
<td class="text-center"><?=$res['diqu']?></td>
<td class="text-center"><?=date("Y.m.d",$res['time'])?></td>
<td class="text-center"><a href="./fank_list.php?my=del&id=<?=$res['id']?>" class="btn btn-xs btn-danger" onclick="if(!confirm('你确实要删除此记录吗？')){return false;}">删除</a></td>
<?php }
?>
          </tbody>
        </table>
      </div>
<?php
echo'<ul class="pagination">';
$first=1;
$prev=$page-1;
$next=$page+1;
$last=$pages;
if ($page>1)
{
echo '<li><a href="fank_list.php?page='.$first.$link.'">首页</a></li>';
echo '<li><a href="fank_list.php?page='.$prev.$link.'">&laquo;</a></li>';
} else {
echo '<li class="disabled"><a>首页</a></li>';
echo '<li class="disabled"><a>&laquo;</a></li>';
}
for ($i=1;$i<$page;$i++)
echo '<li><a href="fank_list.php?page='.$i.$link.'">'.$i .'</a></li>';
echo '<li class="disabled"><a>'.$page.'</a></li>';
for ($i=$page+1;$i<=$pages;$i++)
echo '<li><a href="fank_list.php?page='.$i.$link.'">'.$i .'</a></li>';
echo '';
if ($page<$pages)
{
echo '<li><a href="fank_list.php?page='.$next.$link.'">&raquo;</a></li>';
echo '<li><a href="fank_list.php?page='.$last.$link.'">尾页</a></li>';
} else {
echo '<li class="disabled"><a>&raquo;</a></li>';
echo '<li class="disabled"><a>尾页</a></li>';
}
echo'</ul>';
#分页
?>
    </div> 
         </div>    
              </div>
		 </div>
    </body>
</html>
<?php
}else{ 
    exit("<script language='javascript'>window.location.href='../Kyun/index.php';</script>");
}
?>