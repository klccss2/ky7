<?php
/**
 *===================================
 * 项目：快云流控管理系统
 * 功能：显示平台用户发布情况
 * 作者：by 飞跃 
 * 时间：2017年11月4日 22点48分
 * 版权：归快云免流所有
 *===================================
 */
 
// 加载系统配置文件
require("../../Data/system.php");

if($is_login == 'ok'){
$db = db("openvpn");
// 北京市用户情况
$bjnum = $db->where(array('area'=>'北京市'))->getnums();
// 天津市用户情况
$tjnum = $db->where(array('area'=>'天津市'))->getnums();
//上海市用户情况
$shnum = $db->where(array('area'=>'上海市'))->getnums();
//重庆市用户情况
$cqnum = $db->where(array('area'=>'重庆市'))->getnums();
//湖南省用户情况
$hnnum = $db->where(array('area'=>'湖南省'))->getnums();
//湖北省用户情况
$hbnum = $db->where(array('area'=>'湖北省'))->getnums();
//广东省用户情况
$gdnum = $db->where(array('area'=>'广东省'))->getnums();
//广西壮族自治区用户情况
$gxnum = $db->where(array('area'=>'广西壮族自治区'))->getnums();
//四川省用户情况
$scnum = $db->where(array('area'=>'四川省'))->getnums();
//贵州省用户情况
$gznum = $db->where(array('area'=>'贵州省'))->getnums();
//河南省用户情况
$henum = $db->where(array('area'=>'河南省'))->getnums();
//河北省用户情况
$hanum = $db->where(array('area'=>'河北省'))->getnums();
//山东省用户情况
$sdnum = $db->where(array('area'=>'山东省'))->getnums();
//山西省用户情况
$sxnum = $db->where(array('area'=>'山西省'))->getnums();
//江西省用户情况
$jxnum = $db->where(array('area'=>'江西省'))->getnums();
//江苏省用户情况
$jsnum = $db->where(array('area'=>'江苏省'))->getnums();
//安徽省用户情况
$ahnum = $db->where(array('area'=>'安徽省'))->getnums();
//浙江省用户情况
$zjnum = $db->where(array('area'=>'浙江省'))->getnums();
//福建省用户情况
$fjnum = $db->where(array('area'=>'福建省'))->getnums();
//海南省用户情况
$hinum = $db->where(array('area'=>'海南省'))->getnums();
//云南省用户情况
$ynnum = $db->where(array('area'=>'云南省'))->getnums();
//辽宁省用户情况
$lnnum = $db->where(array('area'=>'辽宁省'))->getnums();
//吉林省用户情况
$jlnum = $db->where(array('area'=>'吉林省'))->getnums();
//黑龙江省用户情况
$hlnum = $db->where(array('area'=>'黑龙江省'))->getnums();
//陕西省用户情况
$snnum = $db->where(array('area'=>'陕西省'))->getnums();
//甘肃省用户情况
$gsnum = $db->where(array('area'=>'甘肃省'))->getnums();
//青海省用户情况
$qhnum = $db->where(array('area'=>'青海省'))->getnums();
//台湾省用户情况
//$twnum = $db->where(array('area'=>'台湾省'))->getnums();
//宁夏回族自治区用户情况
$nxnum = $db->where(array('area'=>'宁夏回族自治区'))->getnums();
//新疆维吾尔族自治区用户情况
$xjnum = $db->where(array('area'=>'新疆维吾尔族自治区'))->getnums();
//西藏藏族自治区用户情况
$xznum = $db->where(array('area'=>'西藏藏族自治区'))->getnums();
//内蒙古自治区用户情况
$nmnum = $db->where(array('area'=>'内蒙古自治区'))->getnums();
// 移动用户数量
$ydnum = $db->where(array('isp'=>'移动'))->getnums();
// 联通用户数量
$ltnum = $db->where(array('isp'=>'联通'))->getnums();
// 电信用户数量
$dxnum = $db->where(array('isp'=>'电信'))->getnums();
?>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <meta name="renderer" content="webkit">

    <title>高级管理 - 用户分布情况</title>

    <meta name="keywords" content="快云免流，快云流控，快云流量，NB免流，NB流控">
    <meta name="description" content="快云免流，快云流控，快云流量，NB免流，NB流控">
    <link rel="shortcut icon" href="../favicon.ico"> 
	<link href="../../assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="../../assets/css/font-awesome.css" rel="stylesheet">
    <link href="../../assets/css/animate.css" rel="stylesheet">
    <link href="../../assets/css/style.css" rel="stylesheet">
	<script src="../../assets/js/amcharts.js"></script>
    <script src="../../assets/js/pie.js"></script>
    <link href="../../assets/css/export.css" rel="stylesheet"/>
    <script src="../../assets/js/light.js"></script>
<style>
.UserNum {
  width: 100%;
  height: 500px;
}											
</style>
</head>	
<body class="gray-bg">
    <div class="wrapper wrapper-content">
        <div class="row">
		       <div class="col-sm-12">
			<div class="ibox-mulu">
      <h3> &nbsp;&nbsp; <i class="fa fa-users fa-lg"></i> 账号管理 > 用户分布</h3>
              </div>
			  <br>
			  <div class="row">
			 <div class="col-sm-6">
                 <div class="ibox">
                    <div class="ibox-content">
                  <div class="row">
				   <h4> &nbsp; 运营商分布情况<h4>
                 <div class="UserNum" id="Carrieroperator"></div>																																																																																																																																																
		</div>
		  </div>
                </div>
            </div>
            <div class="col-sm-6">
                 <div class="ibox">
                    <div class="ibox-content">
                  <div class="row">
				  <h4> &nbsp; 市区用户分布情况<h4>
                 <div class="UserNum" id="UserNum_two"></div>																																																																																																																																																
		</div>
		  </div>
                </div>
            </div>
            <div class="col-sm-6">
                 <div class="ibox">
                    <div class="ibox-content">
                  <div class="row">
				  <h4> &nbsp; 南方用户分布情况<h4>
                 <div class="UserNum" id="UserNum_one"></div>																																																																																																																																																
		</div>
		  </div>
                </div>
            </div>
			
            <div class="col-sm-6">
                 <div class="ibox">
                    <div class="ibox-content">
                  <div class="row">
				  <h4> &nbsp; 北方用户分布情况<h4>
                 <div class="UserNum" id="UserNum_three"></div>																																																																																																																																																
		</div>
		  </div>
		  </div>
                </div>
            </div>
		</div> 	
             </div>		
      </div>
 </body>
 <script>
var chart = AmCharts.makeChart( "UserNum_one", {
  "type": "pie",
  "theme": "light",
  "dataProvider": [ {
    "省份": "湖南省",
    "人数": <?php echo $hnnum;?>
  }, {
    "省份": "湖北省",
    "人数": <?php echo $hbnum;?>
  }, {
    "省份": "海南省",
    "人数": <?php echo $hinum;?>
  }, {
    "省份": "江西省",
    "人数": <?php echo $jxnum;?>
  }, {
    "省份": "江苏省",
    "人数": <?php echo $jsnum;?>
  }, {
    "省份": "浙江省",
    "人数": <?php echo $zjnum;?>
  }, {
    "省份": "福建省",
    "人数": <?php echo $fjnum;?>
  }, {
    "省份": "安徽省",
    "人数": <?php echo $ahnum;?>
  }, {
    "省份": "广东省",
    "人数": <?php echo $gdnum;?>
  }, {
    "省份": "贵州省",
    "人数": <?php echo $gznum;?>
  }, {
    "省份": "四川省",
    "人数": <?php echo $scnum;?>
  }, {
    "省份": "云南省",
    "人数": <?php echo $ynnum;?>
  }],
  "valueField": "人数",
  "titleField": "省份",
  "outlineAlpha": 0.4,
  "depth3D": 15,
  "balloonText": "[[title]]<br><span style='font-size:12px'><b>用户：[[value]]人</b></span>",
  "angle": 30,
  "export": {
    "enabled": true
  }
} );

var chart = AmCharts.makeChart( "UserNum_two", {
  "type": "pie",
  "theme": "light",
  "dataProvider": [ {
    "省份": "北京市",
    "人数": <?php echo $bjnum;?>
  }, {
    "省份": "上海市",
    "人数": <?php echo $shnum;?>
  }, {
    "省份": "重庆省",
    "人数": <?php echo $cqnum;?>
  }, {
    "省份": "天津市",
    "人数": <?php echo $tjnum;?>
  }, {
    "省份": "内蒙古自治区",
    "人数": <?php echo $nmnum;?>
  }, {
    "省份": "新疆自治区",
    "人数": <?php echo $xjnum;?>
  }, {
    "省份": "宁夏自治区",
    "人数": <?php echo $nxnum;?>
  }, {
    "省份": "西藏自治区",
    "人数": <?php echo $xznum;?>
  }, {
    "省份": "广西自治区",
    "人数": <?php echo $gxnum;?>
  } ],
  "valueField": "人数",
  "titleField": "省份",
  "outlineAlpha": 0.4,
  "depth3D": 15,
  "balloonText": "[[title]]<br><span style='font-size:12px'><b>用户：[[value]]人</b></span>",
  "angle": 30,
  "export": {
    "enabled": true
  }
} );

var chart = AmCharts.makeChart( "UserNum_three", {
  "type": "pie",
  "theme": "light",
  "dataProvider": [  {
    "省份": "甘肃省",
    "人数": <?php echo $gsnum;?>
  },{
    "省份": "青海省",
    "人数": <?php echo $qhnum;?>
  }, {
    "省份": "陕西省",
    "人数": <?php echo $snnum;?>
  }, {
    "省份": "河北省",
    "人数": <?php echo $hanum;?>
  }, {
    "省份": "河南省",
    "人数": <?php echo $henum;?>
  }, {
    "省份": "黑龙江省",
    "人数": <?php echo $hlnum;?>
  }, {
    "省份": "吉林省",
    "人数": <?php echo $jlnum;?>
  }, {
    "省份": "辽宁省",
    "人数": <?php echo $lnnum;?>
  }, {
    "省份": "山东省",
    "人数": <?php echo $sdnum;?>
  }, {
    "省份": "山西省",
    "人数": <?php echo $sxnum;?>
  }],
  "valueField": "人数",
  "titleField": "省份",
  "outlineAlpha": 0.4,
  "depth3D": 15,
  "balloonText": "[[title]]<br><span style='font-size:12px'><b>用户：[[value]]人</b></span>",
  "angle": 30,
  "export": {
    "enabled": true
  }
} );

var chart = AmCharts.makeChart( "Carrieroperator", {
  "type": "pie",
  "theme": "light",
  "dataProvider": [ {
    "运营商": "中国移动",
    "人数": <?php echo $ydnum;?>
  },{
    "运营商": "中国电信",
    "人数": <?php echo $dxnum;?>
  }, {
    "运营商": "中国联通",
    "人数": <?php echo $ltnum;?>
  }],
  "valueField": "人数",
  "titleField": "运营商",
  "outlineAlpha": 0.4,
  "depth3D": 15,
  "balloonText": "[[title]]<br><span style='font-size:12px'><b>用户：[[value]]人</b></span>",
  "angle": 30,
  "export": {
    "enabled": true
  }
} );
</script>
</html>
<?php
}else{ 
    exit("<script language='javascript'>window.location.href='../Kyun/index.php';</script>");
}
?>