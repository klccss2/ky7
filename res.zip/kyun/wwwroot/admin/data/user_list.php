<?php
/**
 *===================================
 * 项目：快云流控管理系统
 * 功能：显示平台所有用户信息
 * 作者：by 飞跃 
 * 时间：2017年11月4日 22点48分
 * 版权：归快云免流所有
 *===================================
 */
 
// 加载系统配置文件
require("../../Data/system.php");

if($is_login == 'ok'){
$db = db("openvpn");
?>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">


    <title>账号管理 - 账号列表</title>
    <meta name="keywords" content="">
    <meta name="description" content="">

    <link rel="shortcut icon" href="favicon.ico"> 
	<link href="../../assets/css/bootstrap.min.css?v=3.3.6" rel="stylesheet">
    <link href="../../assets/css/font-awesome.css" rel="stylesheet">

    <link href="../../assets/css/animate.css" rel="stylesheet">
    <link href="../../assets/css/style.css" rel="stylesheet">

</head>

<body class="gray-bg">

<div class="wrapper wrapper-content animated fadeInUp">
<div class="row">
  <div class="col-sm-12">
			<div class="ibox-mulu">
      <h3> &nbsp;&nbsp; <i class="fa fa-users fa-lg"></i> 账号管理 > 账号列表</h3>
              </div>
			  <br>	
<?php
if($_GET['my']){
$my=$_GET['my'];
$user=daddslashes($_GET['user']);
if($my=='del_user'){	
  if(db("openvpn")->where(array('iuser'=>$user))->delete()){				 
      echo Skip('删除账号【'.$user.'】',success);
  }else{
      echo Skip('删除账号【'.$user.'】',error);
  }
}elseif($my=='jy_user'){
  if($db->where(array('i'=>'0'))->delete()){				 
      echo Skip('删除已禁用账号',success);
  }else{
      echo Skip('删除已禁用账号',error);
  }
}elseif($my=='wjh_user'){
   if($db->where(array('i'=>'2'))->delete()){				 
      echo Skip('删除未激活账号',success);
   }else{
      echo Skip('删除未激活账号',error);
   }
 }
exit;
}elseif(!empty($_GET['kw'])) {
	$numrows = $db->where(array('iuser'=>$_GET['kw']))->getnums();
}else{
	$numrows = $db->where(array())->getnums();
}
echo '<div class="ibox">
    <div class="ibox-content">
<form action="./user_list.php" method="get" class="form-inline">
  <div class="form-group">
    <input type="text" class="form-control" name="kw" placeholder="请输入账号">
  </div>
  <button type="submit" class="btn btn-primary">搜索</button>
    <a href="#" class="btn btn-success">平台共有 <b>'.$numrows.'</b> 个账号</a>
	  <a href="user_list.php?my=jy_user" class="btn btn-danger" onclick="return confirm(\'你确实要进行操作吗？\');">删除已禁用账号</a>
     <a href="user_list.php?my=wjh_user" class="btn btn-danger" onclick="return confirm(\'你确实要进行操作吗？\');">删除未激活账号</a>
</form>';
?>
      <div class="table-responsive">
         <table class="table table-bordered table-hover">
          <thead><tr><th class="text-center">ID</th><th class="text-center">账号</th><th class="text-center">密码</th><th class="text-center">状态</th><th class="text-center">剩余流量</th><th class="text-center">总流量</th><th class="text-center">添加时间</th><th class="text-center">到期时间</th><th class="text-center">操作</th></tr></thead>
          <tbody>
<?php
$pagesize=50;
$pages=intval($numrows/$pagesize);
if ($numrows%$pagesize)
{
 $pages++;
 }
if (isset($_GET['page'])){
$page=intval($_GET['page']);
}
else{
$page=1;
}
$offset=$pagesize*($page - 1);
if(isset($_GET['kw'])){
    $user_list = $db->where(array('iuser'=>$_GET['kw']))->order('id desc')->limit($offset,$pagesize)->select();
}else{
	$user_list = $db->where(array())->order('id desc')->limit($offset,$pagesize)->select();
}
foreach($user_list as $res){ 
if($res["i"] == "1" ){
	$i='<span class="label label-primary">已开通</span>';
	$date=(date("Y.m.d",$res['endtime']));
}elseif($res['i'] == "2"){
	$i='<span class="label label-danger">未激活</span>';
	$date='<span class="label label-warning">等待激活</span>';
}else{
	$i='<span class="label label-danger">已禁用</span>';
	$date=(date("Y.m.d",$res['endtime']));
}
if(date("Y-m-d",$res['starttime']) == date("Y-m-d",time())){
	$p = '&nbsp;<span class="label label-success">今日新增</span>';
}elseif(date("Y-m-d",$res['starttime']) == date("Y-m-d",(time()-24*60*60))){
	$p = '&nbsp;<span class="label label-info">昨日新增</span>';
}else{
	$p ="";
}		
?>
<tr>
<td class="text-center"><?=$res['id']?></td>
<td class="text-center"><?=$res['iuser']?><?=$p?></td>
<td class="text-center"><?=$res['pass']?></td>
<td class="text-center"><?=$i?></td>
<td class="text-center"><?=round(($res['maxll']-$res['isent']-$res['irecv'])/1024/1024)?> MB</td>
<td class="text-center"><?=round(($res['maxll'])/1024/1024)?> MB</td>
<td class="text-center"><?=date("Y.m.d",$res['starttime'])?></td>
<td class="text-center"><?=$date?></td>
<td class="text-center"><a class="btn btn-xs btn-success" href="./uesr_set.php?user=<?=$res['iuser']?>">配置</a>&nbsp;<a href="./user_list.php?my=del_user&user=<?=$res['iuser']?>" class="btn btn-xs btn-danger" onclick="if(!confirm('你确实要删除此记录吗？')){return false;}">删除</a></td>
</tr>

<?php }
?>
          </tbody>
        </table>
      </div>
<?php
echo'<ul class="pagination">';
$first=1;
$prev=$page-1;
$next=$page+1;
$last=$pages;
if ($page>1)
{
echo '<li><a href="user_list.php?page='.$first.$link.'">首页</a></li>';
echo '<li><a href="user_list.php?page='.$prev.$link.'">&laquo;</a></li>';
} else {
echo '<li class="disabled"><a>首页</a></li>';
echo '<li class="disabled"><a>&laquo;</a></li>';
}
for ($i=1;$i<$page;$i++)
echo '<li><a href="user_list.php?page='.$i.$link.'">'.$i .'</a></li>';
echo '<li class="disabled"><a>'.$page.'</a></li>';
for ($i=$page+1;$i<=$pages;$i++)
echo '<li><a href="user_list.php?page='.$i.$link.'">'.$i .'</a></li>';
echo '';
if ($page<$pages)
{
echo '<li><a href="user_list.php?page='.$next.$link.'">&raquo;</a></li>';
echo '<li><a href="user_list.php?page='.$last.$link.'">尾页</a></li>';
} else {
echo '<li class="disabled"><a>&raquo;</a></li>';
echo '<li class="disabled"><a>尾页</a></li>';
}
echo'</ul>';
#分页
?>
    </div>

 
                  
              </div>
            </section>
			  </div>
                        </div>
                    </div>
    </body>
</html>
<?php
}else{ 
    exit("<script language='javascript'>window.location.href='../Kyun/index.php';</script>");
}
?>