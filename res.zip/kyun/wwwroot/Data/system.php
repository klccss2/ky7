<?php
/**
 *===================================
 * 项目：快云流控管理系统
 * 功能：系统全部配置文件合集
 * 作者：by 飞跃 
 * 时间：2017年11月4日 22点48分
 * 版权：归快云免流所有
 *===================================
 */
error_reporting(0);
define('Whether', true);
date_default_timezone_set('PRC'); // 中国时区
define('RT', dirname(__FILE__).'/');
define('RI', dirname(__FILE__).'/Class/');
require(RT.'config.php');
require(RI.'D.class.php');	
require(RI.'K.class.php');
require(RI.'S.class.php');
require(RI.'M.class.php');
require(RT.'function.php');
session_start(); //启用Session会话
//全局SQL注入
SqlBase::_deal();
$is_login = admin_login();
$now = date("Y-m-d H:i:s");
$NowVersion = '7.0';