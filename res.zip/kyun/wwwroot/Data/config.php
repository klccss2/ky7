<?php
/**
 *===================================
 * 项目：快云流控管理系统
 * 功能：系统数据库配置文件
 * 作者：by 飞跃 
 * 时间：2017年11月4日 22点48分
 * 版权：归快云免流所有
 *===================================
 */
define("mysql_host","localhost");
define("mysql_user","root");
define("mysql_pass","SetPass");
define("mysql_port","3306");
define("mysql_data","Kyml");
