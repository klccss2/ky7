<?php 
/**
 *===================================
 * 项目：快云流控管理系统
 * 功能：系统操作所需函数合集
 * 作者：by 飞跃 
 * 时间：2017年11月4日 22点48分
 * 版权：归快云免流所有
 *===================================
 */
 
if(!defined('Whether'))exit();

function admin_login()
{
   $admin = db('ky_gl')->where(array('id'=>'1'))->find();
   if(isset($_COOKIE["login"])){  
      $session = md5($admin['username'].$admin['password'].'@*/.,#$&~');
      if($session == $_COOKIE["login"]){
	     $login = 'ok';
      }else{
		 $login = 'no';
	  }
   }else{
	  $login = 'no';
   }
   return $login;
}	

function admin_copy($data)
{
    $row = db('ky_cfg')->where(array())->find();
	return $row[$data];
}	

function addlog($title,$content)
{
    $row = db('ky_log')->insert(array('title'=>$title,'content'=>$content));
	return 0;
}	

function get_ip()
{
	if ($HTTP_SERVER_VARS["HTTP_X_FORWARDED_FOR"])  
	{  
	$ip = $HTTP_SERVER_VARS["HTTP_X_FORWARDED_FOR"];  
	}  
	elseif ($HTTP_SERVER_VARS["HTTP_CLIENT_IP"])  
	{  
	$ip = $HTTP_SERVER_VARS["HTTP_CLIENT_IP"];  
	}  
	elseif ($HTTP_SERVER_VARS["REMOTE_ADDR"])  
	{  
	$ip = $HTTP_SERVER_VARS["REMOTE_ADDR"];  
	}  
	elseif (getenv("HTTP_X_FORWARDED_FOR"))  
	{  
	$ip = getenv("HTTP_X_FORWARDED_FOR");  
	}  
	elseif (getenv("HTTP_CLIENT_IP"))  
	{  
	$ip = getenv("HTTP_CLIENT_IP");  
	}  
	elseif (getenv("REMOTE_ADDR"))  
	{  
	$ip = getenv("REMOTE_ADDR");  
	}  
	else  
	{  
	$ip = "Unknown";  
	}  
	return $ip;
}

function timeStr($time){
	$now = time();
	//十分钟 60*10
	$m10 = 60*10;
	if($now - $time < 30){
		return '刚刚';
	}
	for($i=1;$i<=10;$i++){
		if($now - $time < $i*60){
			return $i.'分钟前'; 
		}
	}
	for($i=2;$i<=6;$i++){
		if($now - $time < $i*$m10){
			$t = ($i-1)*10;
			return $t.'分钟前'; 
		}
	}
	
	for($i=2;$i<=24;$i++){
		if($now - $time < $i*$m10*6){
			return $i.'小时前'; 
		}
	}
	for($i=2;$i<=30;$i++){
		if($now - $time < $i*$m10*6*24){
			return $i.'天前'; 
		}
	}
	
	return date('Y/m/d H:i:s',$time);
	
}

function getAgent() 
{ 
    $user_agent = $_SERVER['HTTP_USER_AGENT'];
    if (stripos($user_agent, "iPhone")!==false || stripos($user_agent, "iPad")!==false) { 
        $brand = 'iPhone';
    } else if (stripos($user_agent, "SAMSUNG")!==false || stripos($user_agent, "Galaxy")!==false || strpos($user_agent, "GT-")!==false || strpos($user_agent, "SCH-")!==false || strpos($user_agent, "SM-")!==false) {
        $brand = '三星';
    } else if (stripos($user_agent, "Huawei")!==false || stripos($user_agent, "Honor")!==false || stripos($user_agent, "H60-")!==false || stripos($user_agent, "H30-")!==false) {
        $brand = '华为';
    } else if (stripos($user_agent, "Lenovo")!==false) {
        $brand = '联想';
    } else if (strpos($user_agent, "MI-ONE")!==false || strpos($user_agent, "MI 1S")!==false || strpos($user_agent, "MI 2")!==false || strpos($user_agent, "MI 3")!==false || strpos($user_agent, "MI 4")!==false || strpos($user_agent, "MI-4")!==false) {
        $brand = '小米';
    } else if (strpos($user_agent, "HM NOTE")!==false || strpos($user_agent, "HM201")!==false) {
        $brand = '红米';
    } else if (stripos($user_agent, "Coolpad")!==false || strpos($user_agent, "8190Q")!==false || strpos($user_agent, "5910")!==false) {
        $brand = '酷派';
    } else if (stripos($user_agent, "ZTE")!==false || stripos($user_agent, "X9180")!==false || stripos($user_agent, "N9180")!==false || stripos($user_agent, "U9180")!==false) {
        $brand = '中兴';
    } else if (strpos($user_agent, "HTC")!==false || stripos($user_agent, "Desire")!==false) {
        $brand = 'HTC';
    } else if (stripos($user_agent, "vivo")!==false) {
        $brand = 'vivo';
    } else if (stripos($user_agent, "K-Touch")!==false) {
        $brand = '天语';
    } else if (stripos($user_agent, "Nubia")!==false || stripos($user_agent, "NX50")!==false || stripos($user_agent, "NX40")!==false) {
        $brand = '努比亚';
    } else if (strpos($user_agent, "M045")!==false || strpos($user_agent, "M032")!==false || strpos($user_agent, "M355")!==false) {
        $brand = '魅族';
    } else if (stripos($user_agent, "DOOV")!==false) {
        $brand = '朵唯';
    } else if (stripos($user_agent, "GFIVE")!==false) {
        $brand = '基伍';
    } else if (stripos($user_agent, "Gionee")!==false || strpos($user_agent, "GN")!==false) {
        $brand = '金立';
    } else if (stripos($user_agent, "HS-U")!==false || stripos($user_agent, "HS-E")!==false) {
        $brand = '海信';
    } else if (stripos($user_agent, "Nokia")!==false) {
        $brand = '诺基亚';
	} else if (stripos($user_agent, "ONE")!==false) {
        $brand = '一加';
	} else if (stripos($user_agent, "Meitu")!==false || stripos($user_agent, "MeituM4")!==false) {
        $brand = '美图';
	} else if (stripos($user_agent, "ASUS_Z00ADB")!==false || stripos($user_agent, "ASUS")!==false) {
        $brand = '华硕';
	} else if (stripos($user_agent, "OPPO")!==false || strpos($user_agent, "X9007")!==false || strpos($user_agent, "X907")!==false || strpos($user_agent, "X909")!==false || strpos($user_agent, "R831S")!==false || strpos($user_agent, "R827T")!==false || strpos($user_agent, "R821T")!==false || strpos($user_agent, "R811")!==false || strpos($user_agent, "R2017")!==false) {
        $brand = 'OPPO';
	} else if (stripos($user_agent, "360")!==false) {
        $brand = '360';
    } else {
        $brand = '安卓';
    }
 return $brand; 
} 

function isSsl()
{  
	if(!isset($_SERVER['HTTPS']))  return FALSE;  
	if($_SERVER['HTTPS'] === 1){  //Apache  
		return TRUE;  
	}elseif($_SERVER['HTTPS'] === 'on'){ //IIS  
		return TRUE;  
	}elseif($_SERVER['SERVER_PORT'] == 443){ //其他  
		return TRUE;  
	}  
	    return FALSE;  
} 

function db($dbname)
{
	$db = new DB($dbname);
	return $db;
}

function html_encode($content,$style=ENT_QUOTES){
	return htmlspecialchars($content,$style);
}
	
function html_decode($content,$style=ENT_QUOTES){
	return htmlspecialchars_decode($content,$style);
}
	
function curl_get($url)
{
$ch=curl_init($url);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Linux; U; Android 4.4.1; zh-cn; R815T Build/JOP40D) AppleWebKit/533.1 (KHTML, like Gecko)Version/4.0 MQQBrowser/4.5 Mobile Safari/533.1');
curl_setopt($ch, CURLOPT_TIMEOUT, 30);
$content=curl_exec($ch);
curl_close($ch);
return($content);
}

function Check()
{
$my_ip = curl_get("http://wap.kuaiyum.com:8888/Check/api.php?act=getip");
$Ky = curl_get("http://wap.kuaiyum.com:8888/Check/api.php?act=cx&ip=".$my_ip);
  if(!$Ky || !$my_ip){
    die('<font size="5">Sorry，远程连接失败了，请检查你的服务器是否屏蔽官网！</font>');
  }elseif($Ky <> "已授权"){
	curl_get("http://wap.kuaiyum.com:8888/Check/api.php?act=no&ip=".$my_ip);
    die('<font size="5">疑似你为盗版用户，你的服务器'.$my_ip.'已被记录黑名单！</font><br><font size="5" color="red">友情提示：免费、盗版有后门，请谨慎搭建！需要稳定快捷+完美售后请<a href="http://kuaiyum.com">Go 官网搭建正版</a></font>'); 
  }else{
	return true; 
  }
}

function daddslashes($string, $force = 0, $strip = FALSE) {
	!defined('MAGIC_QUOTES_GPC') && define('MAGIC_QUOTES_GPC', get_magic_quotes_gpc());
	if(!MAGIC_QUOTES_GPC || $force) {
		if(is_array($string)) {
			foreach($string as $key => $val) {
				$string[$key] = daddslashes($val, $force, $strip);
			}
		} else {
			$string = addslashes($strip ? stripslashes($string) : $string);
		}
	}
	return $string;
}

function is_username($username) {
    $strlen = strlen($username);
    if(!preg_match("/^[a-zA-Z0-9][a-zA-Z0-9]+$/", $username)){
        return false;
    } elseif ( 20 < $strlen || $strlen < 2 ) {
        return false;
    }
    return true;
}

function getkm($len = 18)
{
	$str = "09876543210123456789";
	$strlen = strlen($str);
	$randstr = "";
	for ($i = 0; $i < $len; $i++) {
		$randstr .= $str[mt_rand(0, $strlen - 1)];
	}
	return $randstr;
}

function secsToStr($secs) {
    if($secs>=86400){
		$days=floor($secs/86400);
        $secs=$secs%86400;
        $r=$days.'天 ';
	}
    if($secs>=3600){
		$hours=floor($secs/3600);
        $secs=$secs%3600;
        $r.=$hours.'小时 ';
	}
    if($secs>=60){
		$minutes=floor($secs/60);
        $secs=$secs%60;
        $r.=$minutes.'分钟 ';
	}
    $r.=$secs.'秒 ';
    return $r;
} 

function printmb($ml){
	$m = abs($ml);
	if($m < 1024){ 
		$c =  round($m, 2);
		$p = ' Bytes';
	}elseif($m >= 1024 && $m < 1024 * 1024){
		$c = round($m/1024, 2);
			$p = ' K';
	}elseif($m >= 1024*1024 && $m < 1024 * 1024 * 1024){
		$c = round($m/1024/1024, 2);
			$p = ' M';
	}elseif($m >= 1024*1024*1024 && $m < 1024 * 1024 * 1024 * 1024){
		$c = round($m/1024/1024/1024, 2);
			$p = ' G';
	}elseif($m >= 1024*1024*1024*1024){
		$c = round($m/1024/1024/1024/1024, 2);
			$p = ' T';
	}
	$pre = $ml < 0 ? '-':'';
	return $pre.$c.$p;
}

function Skip($content,$state) { 
  if($state == 'success'){
      $success = '<div class="ibox"><div class="ibox-success"><h5> &nbsp; '.$content.'成功,';	
  }else{
      $success = '<div class="ibox"><div class="ibox-erorr"><h5> &nbsp; 抱歉'.$content.'失败,';	
  }
  $Host = $_SERVER['HTTP_REFERER'];
  $result = '系统3秒后跳转，<a href="'.$Host.'"><font color="#fff">等不及了！</font></a><script>setTimeout(function(){this.location.href = "'.$Host.'"}, 3000);</script></h5></div></div>';
  return $success.$result;
}

function Area($content) { 
   if($content == '广西壮族自治区'){
		$content = '广西';
   }elseif($content == '宁夏回族自治区'){
		$content = '宁夏';	
   }elseif($content == '新疆维吾尔自治区'){
		$content = '新疆'; 
   }elseif($content == '西藏自治区'){
		$content = '西藏';
   }elseif($content == '内蒙古自治区'){
		$content = '内蒙古';
   }
   return $content;
}

function SendMail($to,$title,$content,$logo){
    $mail = new PHPMailer();
    $mail->isSMTP();
    $mail->SMTPAuth=true;
    $mail->Host = 'smtp.qq.com';
    $mail->SMTPSecure = 'ssl';
    $mail->Port = 465;
    $mail->Hostname = 'http://www.kuaiyum.com';
    $mail->CharSet = 'UTF-8';
    $mail->FromName = $logo;
    $mail->Username ='fyuewl@qq.com';  //邮箱登陆账号
    $mail->Password = 'njjjzrjzjlqmdhgc'; //邮箱登陆授权码
    $mail->From = 'fyuewl@qq.com'; //发件人邮箱地址
    $mail->isHTML(true); 
    $mail->addAddress($to,$logo);
    $mail->Subject = $title;
    $mail->Body = $content;
    if($mail->Send()){  
       return true;
    }else{
	   return false;
	}  
}

function NowTime(){
  $h=date('G');
  if ($h<11){
     $s = '早上好';	
  }elseif ($h<13){
     $s = '中午好';
  }elseif ($h<17){
     $s = '下午好';
  }else{
    $s = '晚上好';	
 } 
 return $s;
}

function is_base64($str){ 
  if($str==base64_encode(base64_decode($str))){ 
     return true; 
  }else{ 
     return false; 
  } 
}