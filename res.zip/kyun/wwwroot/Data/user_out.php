<?php
/**
 *===================================
 * 项目：快云流控管理系统
 * 功能：更新用户数据和排行榜
 * 作者：by 飞跃 
 * 时间：2017年11月4日 22点48分
 * 版权：归快云免流所有
 *===================================
 */
 
// 加载系统配置文件
require('system.php');

$username = $argv[1];
$s = $argv[2];
$r = $argv[3];
$db = db('openvpn');
$uinfo = $db->where(array('iuser'=>$username))->find();
$new_s = $uinfo['isent'] + $s;
$new_r = $uinfo['irecv'] + $r;

$db->where(["id"=>$uinfo["id"]])->update(["online"=>0]);
if($new_r+$new_s > $uinfo['maxll']){
	//流量不足 禁用此用户
	$db->where(array("id"=>$uinfo["id"]))->update(array('i'=>"0"));
}
if($db->where(array("id"=>$uinfo["id"]))->update(array('isent'=>$new_s,'irecv'=>$new_r)))
{
	$db2 = db('top');
	$c = $s+$r;
	$u = $db2->where(array('username'=>$username,'time'=>date('Y-m-d',time())))->find();
	if($u){
		$new = $u['data']+$c;
		$db2->where(array('id'=>$u['id']))->update(array('data'=>$new));
	}else{
		$db2->insert(array('username'=>$username,'data'=>$c,'time'=>date('Y-m-d',time())));
	}
}