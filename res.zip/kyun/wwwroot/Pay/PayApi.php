<?php
/* *
 * 功能：支付页面跳转同步通知页面
 * 说明：
 * 以下代码只是为了方便而提供的样例代码，商户可以根据自己网站的需要编写。
 * 该代码仅供学习和研究支付接口使用，只是提供一个参考。
 */
require('../Data/system.php');	 
echo '<html><head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>'.admin_copy(logo).' - 在线购买</title></head>';
/**************************请求参数**************************/
        //接口地址
        $kypay = 'http://pay.kypay.top/Pay/PayApi.php';
		
/************************************************************/
        //返回地址
        $pay_url    = admin_copy('pay_url');
		
/************************************************************/		
        //商户账号
        $pay_user	= admin_copy('pay_user');
		
/************************************************************/
        //商户KEY
        $pay_pass	= admin_copy('pay_pass');
		
/************************************************************/		
        //商户订单号
        $out_trade_no = date("YmdHis").mt_rand(1000,9999);
		
/************************************************************/
		//支付方式
        $type = $_POST['shop_pay'];
		
/************************************************************/		
		// 判断用户购买流量还是代理
		if($_POST['shop_name'] == ""){
            exit("<script>alert('亲，请选择商品再购买哦！');history.go(-1);</script>");
		}
/************************************************************/			
		if($_POST['shop_name'] == "购买代理"){
			   // 代理价格
               $money       =   $_POST['shop_money'];
		       // 商品名称
               $name        =   "购买".admin_copy('logo')."代理";
		}else{
		   $buy = db('ky_tc')->where(array('name'=>$_POST['shop_name']))->find();
		   if(!$buy){
		       exit("<script>alert('抱歉，平台没有该商品！');history.go(-1);</script>");
	       }else{	
		       // 付款金额
               $money       =   $buy['money'];
		       // 商品名称
               $name        =   $buy['name'];
		   }
		}
/************************************************************/		
		//站点名称
        $sitename    =   admin_copy('logo').'在线购买';
		
/************************************************************/
        //加密该订单交易信息
        $BaseTrade = base64_encode($out_trade_no);
		$BaseUrl = base64_encode($pay_url);

/************************************************************/
if(db('ky_buy')->insert(array('trade'=>$out_trade_no,'i'=>'0','tc'=>$name,'money'=>$money,'user'=>$_GET['user'],'dlid'=>$_GET['dlid'],'time'=>time()))){
$HOST = ''.$kypay.'?money='.$money.'&sitename='.$sitename.'&name='.$name.'&type='.$type.'&pay_url='.$BaseUrl.'&pay_user='.$pay_user.'&pay_key='.$pay_key.'&sing='.$BaseTrade.'';
   exit("<script>window.location.href='".$HOST."';</script>");
}else{
   exit("<script>alert('数据库配置错误，请联系管理员！');history.go(-1);</script>");
}
?>