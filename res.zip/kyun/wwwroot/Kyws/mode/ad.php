﻿<?php
$u = $_GET["username"];
$p = $_GET["password"];
$res=db('openvpn')->where(array('iuser'=>$u,'pass'=>$p))->find();
if(!$res){
	die("登录信息错误");
}
if(isset($_POST['km'])){
	$km = $_POST['km'];
	$myrow=db("ky_km")->where(array("kind"=>"1","km"=>$km))->find();
	if(!$myrow){
		die('此激活码不存在');
	}elseif($myrow['isuse']==1){
		die('此激活码已被使用');
	}else{
		$duetime = time() + $myrow['value']*24*60*60;
		$addll = $myrow['values']*1024*1024*1024;
		if(db("openvpn")->where(array('iuser'=>$u))->update(array('maxll'=>$addll,'endtime'=>$duetime,'isent'=>'0','irecv'=>'0','dlid'=>$myrow['daili'],'i'=>'1'))){
			db("ky_km")->where(array("id"=>$myrow['id']))->update(array("isuse"=>"1","user"=>$u,"usetime"=>$now));
			addlog("用户充值",$u."使用卡密".$km."充值了".$myrow['values'].'G流量');
			die('开通成功！');
		}else{
			die('开通失败！');
		}
	}
}
?>
	<div style="margin:10px 10px">
<div class="alert alert-info"><h4>使用说明</h4>
* 充值会<span style="color:red">清空剩余流量</span>，并重设为购买的流量。时间将会设置为充值之日起到充值卡指定的日期结束，超出流量无需补交。</div>
	
	<div class="alert-success" style="display:none;margin:0px;" >
		请在此输入您购买的流量卡密。
	</div> 
				<div class="form-group">
					<input type="text" class="form-control" name="km" placeholder="请输入激活码卡密">
				</div>
				<button type="submit" class="btn btn-success btn-block cz" onclick="kmcz()">
					充值到我的账户
				</button>
				</a>
		
			<br />
			<br />
			
			<br>
			
			</div>
			
		
 <script>
 var old_html = "";
 function kmcz(){
	 if($("[name=km]").val() == ""){
		 $(".alert").html("卡密不能为空").show();
	 }else{
		 old_html = $(".cz").html();
		 $(".cz").html("处理中...");
		 $.post("?act=Shop&username=<?php echo $_GET['username']?>&password=<?php echo $_GET['password']?>",{
			 "km":$("[name=km]").val()
		 },function(data){
			 $(".cz").html(old_html);
			  $(".alert").show();
			  $(".alert").html(data);
		 })
	 }
 }
 </script>