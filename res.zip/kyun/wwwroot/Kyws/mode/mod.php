<?php
	require("../../Data/system.php");
	if(@$_GET["act"]=="mod"){
		$db = db('openvpn');
		if($db->where(array('iuser'=>$_POST["username"],'pass'=>$_POST["pass"]))->find()){
			if($_POST["passnew"] == $_POST["passnew2"]){
				$db->where(array('iuser'=>$_POST["username"],'pass'=>$_POST["pass"]))->update(array('pass'=>trim($_POST["passnew"])));
				die('<script>alert("修改成功");history.go(-1);</script>');
			}else{
				die('<script>alert("两次密码不一致");history.go(-1);</script>');
			}
		}else{
			die('<script>alert("用户不存在或者密码错误");history.go(-1);</script>');
		}
	}else{
	?>
	<link rel="shortcut icon" href="../favicon.ico"> 
	<link href="../../assets/css/bootstrap.min.css?v=3.3.6" rel="stylesheet">
    <link href="../../assets/css/font-awesome.css" rel="stylesheet">
    <link href="../../assets/css/animate.css" rel="stylesheet">
    <link href="../../assets/css/style.css?v=4.1.0" rel="stylesheet">
	<div class="ibox">
     <div class="ibox-content">
	<form action="./mod.php?act=mod" method="post" class="form-horizontal m-t">
	<input type="hidden" name="username" value="<?php echo $_GET['user'];?>"/>
	<div class="form-group">
    <label for="name">请输入您的密码</label>
    <input type="text" class="form-control" name="pass" placeholder="">
  </div>
  <div class="form-group">
    <label for="name">请输入的新密码</label>
    <input type="password" class="form-control" name="passnew" placeholder="">
  </div>
  
  <div class="form-group">
    <label for="name">请再次确认您的新密码</label>
    <input type="password" class="form-control" name="passnew2" placeholder="">
  </div>
  <div class="form-group">
  <button type="submit" class="btn btn-default">确认修改</button>
  </div>
  </form>
  </div>
  </div>
  <?php
	}
	?>