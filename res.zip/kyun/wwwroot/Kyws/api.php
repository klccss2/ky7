<?php
require('../Data/system.php');	
$db= db('openvpn');
$db2 = db('ky_gg');
$db3 = db("ky_yd");
    if($_GET['act'] == 'user_spread'){
		include('head.php');
		include('mode/user.php');
	}elseif($_GET['act'] == 'app_check'){
		$data["status"] = "success";
	    $data["versionCode"] = admin_copy('versionCode');
	    $data["url"] = admin_copy('url'); 
	    $data["content"] = admin_copy('content');
		die(json_encode($data));
	}elseif($_GET['act'] == 'pay'){
		include('head.php');
		include('mode/pay.php');
	}elseif($_GET['act'] == 'spread'){
		include('head.php');
		include('mode/spread.php');
	}elseif($_GET['act'] == 'line'){
		include('head.php');
		include('mode/line.php');
	}elseif($_GET['act'] == 'reg_in'){
		if(admin_copy('u_reg')=='ok'){
		   $username = $_POST['username'];
		   $password = $_POST['password'];
		   $mail = $_POST['mail'];
	       $tjuser = $_POST['tj_user'];	
		   $tj = $db->where(array('iuser'=>$tjuser))->find();	
		   if($tj){
		      $tj_cs = $tj['tj_u'];
		      $tj_kb = $tj['maxll']/1024/1024;
		   }else{
		      $tj_cs = 'no';	
		   }
		   if(trim($username) == '' || trim($password) == '' ){
			  die(json_encode(array('status'=>'error','msg'=>'账号密码不能为空')));
		   }
		   if(!is_username($username)){
			  die(json_encode(array('status'=>'error','msg'=>'账号只能是2~20字母数字')));
		   }
		   if(!is_username($password)){
			  die(json_encode(array('status'=>'error','msg'=>'密码只能是2~20字母数字')));
		   }
		   if($db->where(array('iuser'=>$username))->find()){
			  die(json_encode(array('status'=>'error','msg'=>'该账号已经注册过了哦')));
		   }
		   if($db->where(array('mail'=>$mail))->find()){
			  die(json_encode(array('status'=>'error','msg'=>'该邮箱已经注册过了哦')));
		   }else{
			  if($_GET['dlapp']){
			     $llv = 0;
                 $lly = 0;
                 $lli = 0;			
			  }else{
			     $llv = admin_copy('reg_cash')*1024*1024;
                 $lly = time()+(admin_copy('reg_time')*24*60*60);
                 $lli = 1;		
              }
			  if($db->insert(array('iuser'=>$username,'pass'=>$password,'maxll'=>$llv,'isent'=>'0','irecv'=>'0','i'=>$lli,'starttime'=>time(),'endtime'=>$lly,"mail"=>$mail))){
				 if($tj_cs == 'no'){
				     die(json_encode(array('status'=>'success')));
				 }else{
				    $la = $tj_kb+$reg['user_reg_cash'];
				    $lb = $tj_cs+1;
				    $lc = $la*1024*1024;
				    $db->where(array('iuser'=>$tjuser))->update(array('maxll'=>$lc,'tj_u'=>$lb));
				    die(json_encode(array('status'=>'success')));}
			 }else{
				 die(json_encode(array('status'=>'error','msg'=>'无法正常注册用户 请检查数据库')));
			 }
		  }
		}else{
		  die(json_encode(array('status'=>'error','msg'=>'管理员已关闭注册')));
		}
	}elseif($_GET['act'] == 'SendMail'){
		$mail = $_POST["mail"];
		$user = $_POST["user"];
		$code = $_POST["code"];
		$row = SendMail(''.$mail.'',''.admin_copy('logo').'注册验证码','尊敬的'.$user.','.NowTime().'！<br>你的验证码是：'.$code.'',''.admin_copy('logo').'');
		if($row == true){
			die(json_encode(array('status'=>'success')));
		}else{
			die(json_encode(array('status'=>'error')));
		}
	}elseif($_GET['act'] == 'dx_reg'){
		include('head.php');
		if($_GET['dlapp']){
		    include("mode/app_reg.php");
		}else{
		   if(admin_copy('reg_mode')=='dx'){
			  include("mode/dx_reg.php");
		   }else{
			  include("mode/app_reg.php");  
		   }
		}
	}elseif($_GET['act'] == 'info'){
		include('head.php');
		include("mode/llog.php");
	}elseif($_GET['act'] == 'fank'){
		$user = $_POST['user'];
		$wang = $_POST['wang'];
		$diqu = $_POST['diqu'];
		$lineid = $_POST['id'];
	    $old = db("ky_fk")->where(array('user'=>$user))->order('id DESC')->find();
		if($old){
			if(time()-$old["time"] < 60*30){
			   die(json_encode(array("status"=>"old")));
			}
        }
		$fk = db("ky_fk")->insert(array('user'=>$user,'diqu'=>$diqu,'wang'=>$wang,'lid'=>$lineid,'time'=>time()));
		if($fk){
		    die(json_encode(array('status'=>'success')));	
		}else{
		    die(json_encode(array('status'=>'erorr','msg'=>'反馈失败，请骚后重新尝试')));	
		}
	}elseif($_GET['act'] == 'user_info'){
		include('head.php');
		include("mode/user.php");
	}elseif($_GET['act'] == 'Shop'){
		include('head.php');
		include("mode/ad.php");
	}elseif($_GET['act'] == 'list_gg'){
		include('head.php');
     	$u = $_GET['username'];
		$p = $_GET['password'];
		if($_GET['dlapp']){
			$dlid=$_GET['dlapp'];
		}else{
			$dlid='0';	
		}
		$list = $db2->where(array('dlid'=>$dlid))->order('id DESC')->select();
		echo '<div style="margin:10px 10px;"><div class="alert alert-warning">您可以在这看到最近30条消息通知</div></div>';
		if($list){
			echo '<div class="main"><ul class="list-group">';
			foreach($list as $v){
			   $is_read = $db3->where(array('readid'=>$v['id'],"username"=>$u))->find();
			   $pre = $is_read ? '' :'<span class="badge">未读</span>';
			    echo '<li class="list-group-item"><a href="?act=gg&id='.$v['id'].'&username='.$u.'">'.$pre.$v['name'].'</a></li>';
			}
		    echo '</ul><div>';
		}else{
			echo '消息已经删除或者不存在！';
		}
	}elseif($_GET['act'] == 'gg'){
		include('head.php');
		include('mode/gg_view.php');
	}elseif($_GET['act'] == 'load_gg'){
		$u = $_POST['username'];
		if($_GET['dlapp']){
		    $vo = $db2->where(array('dlid'=>$_GET['dlapp']))->order('id DESC')->find();
		}else{
		    $vo = $db2->where(array('dlid'=>'0'))->order('id DESC')->find();	
		}
		$is_read = $db3->where(array('readid'=>$vo['id'],"username"=>$u))->find();
		if($vo && !$is_read){
			$db3->insert(array('username'=>$u,'readid'=>$vo['id']));
			die(json_encode(array('status'=>'success','url'=>'http://'.$_SERVER["HTTP_HOST"].':'.$_SERVER["SERVER_PORT"].'/Kyws/api.php?act=gg&id='.$vo['id'].'&username='.$u.'&','title'=>$vo['name'],'content'=>$vo['content'])));
		}else{
			die(json_encode(array('status'=>'error','url'=>'no data','title'=>'no data')));
		}	
	}elseif($_GET['act'] == 'load_info'){
		$user = $_POST['username'];
		$pass = $_POST['password'];
		$u = $db->where(array('iuser'=>$user,'pass'=>$pass))->find();
		if($u){
			$sy = printmb($u['maxll']-($u['irecv']+$u['isent']));
			if($sy['n'] <= 0 && $sy['p'] == 'M'){
				$t = 'tips_user';
				$s = round($sy['n'],1).$sy['p'];
			}elseif($sy['n'] <= 100 && $sy['p'] == 'M'){
				$t = 'tips_user';
				$s = round($sy['n'],1).$sy['p'];
			}else{
				$t = 'success';
				$s = round($sy['n'],1).$sy['p'];
			}
			$_sy = round(($u['endtime'] - time()) / 86400);
			$_all = $u['maxll'] >= 100*1024*1024*1024 ? "NO_LIMIT" : $s;
			die(json_encode(array('status'=>$t,'all'=>$u['maxll']-($u['irecv']+$u['isent']),'sy'=>$_all,'stime'=>'2','etime'=>'2','bl'=>$_sy."天")));
		}else{
			die(json_encode(array('status'=>'success','all'=>'0','sy'=>'未知','stime'=>'2','etime'=>'2','bl'=>$_sy."天")));
		}
	}elseif($_GET['act'] == 'top'){
		include('head.php');
		$u = $_GET['username'];
		$p = $_GET['password'];
		$db4 = db('top');
		$list = $db4->limit('100')->where(array("time"=>date("Y-m-d",time())))->order('data DESC')->select();
		$my = $db4->where(array("username"=>$u,"time"=>date("Y-m-d",time())))->find();
		$mytop = $db4->where("data >= :data AND time = :time",array(":data"=>$my["data"],":time"=>date("Y-m-d",time())))->getnums();
		$ml = printmb($my['data']);
		echo '<div class="alert alert-success">
		<b>当前我的排名:以'.$ml.'的成绩位居今天第<font style="color:red">'.$mytop.'</font>名！</b>
		<br>每天流量使用排名前100的会显示在这里哦！【按日结算】</div>
		<style>
		.topline{
			border:1px solid #ccc;
			height:100px;
			margin:10px;
			background:#6aafd7;
			background-image:url("images/topbg.png");
			background-repeat:no-repeat;
			color:#fff;
		}
		.topi{
			font-size:45px;
			float:left;
			line-height:100px;
			margin-left:15px;
			width:100px;
		}
		.topl{
			float:right;
			margin-top:15px;
			margin-right:20%;
			font-size:28px;
		}
		.topc{
			float:right;
			margin-top:7px;
			margin-right:10px;
		}
		</style>';
        $i = 1;
		foreach($list as $vo){	
			$l = printmb($vo['data']);
			$user = db(openvpn)->where(array('iuser'=>$vo['username']))->find();	
			$area = Area($user["area"]); 
			echo '<div class="topline">
			        <div class="topi">'.$i.'</div>
				        <div class="topl">'.$l.'</div>
						    <div class="topc">
							   <img src="images/user.png" height="17" width="16"/> '.substr_replace($vo["username"],'****',3,3).'&nbsp;
			                   <img src="images/shouji.png" height="13" width="8"/> <i>'.$area.''.$user["isp"].'</i> '.$user['client'].'
							   </div>
							 </div>
					     </div>';
	        $i++;
		}
	}elseif($_GET['act'] == 'login_in'){
		$user = $_POST['username'];
		$pass = $_POST['password'];
		$u = $db->where(array('iuser'=>$user,'pass'=>$pass))->find();
		if($u){
			$uinfo = $u;
			if($uinfo['i']=='2'){
			   $tian = $uinfo['tian'];	
			   $endtime = time()+3600*24*$tian;
			   $db->where(array('iuser'=>$u))->update(array('i'=>'1','endtime'=>$endtime,'starttime'=>time()));
		    }
			$max = $u['maxll'];
			$_sy = round(($uinfo['endtime'] - time()) / 86400);
			$count =  printmb($uinfo['maxll']);
			$sy = printmb($uinfo['maxll']-($uinfo['irecv']+$uinfo['isent']));
			$s = $max>=100*1024*1024*1024 ? "NO_LIMIT" : round($sy['n'],1)." ".$sy['p'];
			die(json_encode(array(
				'status'=>'success',
				'msg'=>base64_encode($u['iuser']."\n".$u['pass']."\n".$sy."\n".$count."\n".round($_sy,0)),
				'username'=>$uinfo['iuser'],
				'password'=>$uinfo['pass'],
				'liuliang'=>$s,
				'all'=>$count,
				'bl'=>$_sy."天"
			)));
		}else{
			die(json_encode(array(
				'status'=>'error',
				'msg'=>'用户不存在或者密码错误'
			)));
		}
	}elseif($_GET['act'] == 'login_check'){
		$u = $_POST['username'];
		$p = $_POST['pass'];
		$res = $db->where(array('iuser'=>$u,pass=>$p))->find();
		$png = admin_copy('splash');
		$url = admin_copy('splashurl');
		if($res){
			if($res['client']==NULL){
			   $agent = getAgent();
			   $db->where(array('iuser'=>$u))->update(array('client'=>$agent));
			}elseif($res['area']==NULL && $res['area']==NULL){
			   $ip = get_ip(); 
			   if($ip == 'Unknow'){
			      $db->where(array('iuser'=>$u))->update(array('area'=>'未知地区','isp'=>'未知','client'=>$agent));
			   }else{
			      $api_uri = "http://ip.taobao.com/service/getIpInfo.php?ip={$ip}";
			      $json = file_get_contents($api_uri); 
			      $arr = json_decode($json,true); 
			      $region = $arr["data"]["region"];
			      $isp = $arr["data"]["isp"]; 
			      $db->where(array('iuser'=>$u))->update(array('area'=>$region,'isp'=>$isp));
			   }
			}
			$sydata = $res['maxll']-($res['irecv']+$res['isent']);
			$_sy = round(($res['endtime'] - time()) / 86400);
			$max = $res['maxll'];
			$count =  printmb($max);
			$sy = printmb($sydata);
			$s = $max>=100*1024*1024*1024 ? "NO_LIMIT" : $sy;
			$data = "success_need_login\n";
			$data .= $res['iuser']."\n";
			$data .= $res['pass']."\n";
			$data .= $s."\n";
			$data .= $sydata."\n";
			$data .= $_sy."天\n";
			$data .= $png."\n";
			$data .= $url;
			die($data);
		}else{
			$data = "error_need_login\n";
			$data .= "0\n";
			$data .= "0\n";
			$data .= "0\n";
			$data .= "0\n";
			$data .= "0\n";
			$data .= $png."\n";
			$data .= $url;
			die($data);
		}
	}elseif($_GET['act'] == 'theme'){
		include('mode/theme.php');	
	}elseif($_GET['act'] == 'help'){
		include('head.php');
        include("mode/help.php");
	}elseif($_GET['act'] == 'more'){
		include('head.php');
		include('mode/all.php');  
	}else{
		echo '<center>
              <img src="http://'.$_SERVER['SERVER_NAME'].':'.$_SERVER["SERVER_PORT"].'/assets/img/404.png" width="60%" height="60%"/>
             </center>';
    } ?>