<?php
/**
 *===================================
 * 项目：快云流控管理系统
 * 功能：加盟商登陆到管理系统
 * 作者：by 飞跃 
 * 时间：2017年11月4日 22点48分
 * 版权：归快云免流所有
 *===================================
 */
 
// 加载系统配置文件
require("../../Data/system.php");
?>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0,user-scalable=no"/>
    <link rel="shortcut icon" href="../img/favicon_1.ico">

    <title>加盟商登录 - <?php echo admin_copy(logo);?></title>
    <meta name="keywords" content="快云免流，快云流控，快云流量，NB免流，NB流控">
    <meta name="description" content="快云免流，快云流控，快云流量，NB免流，NB流控">
	<link href="../../assets/css/font-awesome.css" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="css/core.css" rel="stylesheet" type="text/css">
    <link href="css/components.css" rel="stylesheet" type="text/css">
    <link href="css/pages.css" rel="stylesheet" type="text/css">
    <link href="css/responsive.css" rel="stylesheet" type="text/css">
	<link href="../assets/css/font-awesome.css" rel="stylesheet" type="text/css">


</head>
<body>


<div class="wrapper-page">
    <div class="panel panel-color panel-primary panel-pages">
        <div class="panel-heading bg-img">
            <div class="bg-overlay"></div>
            <h3 class="text-center m-t-10 text-white"><strong><?php echo admin_copy(logo);?>加盟商后台</strong> </h3>
        </div>

        <div class="panel-body">
            <form class="form-horizontal m-t-20" action="../index.php" method="post">

                <div class="form-group">
                    <div class="col-xs-12">
                        <input class="form-control input-lg" type="text" required="" name="user" placeholder="请输入管理员账号">
                    </div>
                </div>

                <div class="form-group">
                    <div class="col-xs-12">
                        <input class="form-control input-lg" type="password" required="" name="pass" placeholder="请输入管理员密码">
                    </div>
                </div>

                <div class="form-group text-center m-t-40">
                    <div class="col-xs-12">
                        <button class="btn btn-primary form-control" type="submit">立 即 登 陆</button>
                    </div>
                </div>

                <div class="form-group m-t-30">
                    <div class="col-sm-7">
                        <a onclick="alert('请联系超级管理员找回密码哦！')"><i class="fa fa-lock m-r-5"></i> 忘记密码?</a>
                    </div>
                    <div class="col-sm-5 text-right">
                        <a href="reg_user.php">免费注册</a>
                    </div>
                </div>
            </form>
        </div>

    </div>
</div>
</body>
</html>