<?php
/**
 *===================================
 * 项目：快云流控管理系统
 * 功能：代理登陆账号密码验证
 * 作者：by 飞跃 
 * 时间：2017年11月4日 22点48分
 * 版权：归快云免流所有
 *===================================
 */
  
// 加载系统配置文件
require("../Data/system.php");

$dlid = $_SESSION['dlid'];
if(isset($_POST['user']) && isset($_POST['pass'])){
	 $user=daddslashes($_POST['user']);
	 $pass=daddslashes($_POST['pass']);
	 $daili = db("ky_dl")->where(array('user'=>$user,'pass'=>$pass))->find();
	 if($daili){
		 if($daili['status']=='ok'){
			 if($daili['endtime'] < time()){
				 exit("<script>alert('账号已到期，请联系管理员续费！');history.go(-1);</script>");
			 }else{
			     $_SESSION['dlid']=$daili['id'];
			     exit("<script>alert('登陆管理中心成功！');window.location.href='./data/index.php';</script>");
			 }
		 }else{
			 exit("<script>alert('账号未激活，请联系管理员！');history.go(-1);</script>");
		 }
	 }else{
		 exit("<script>alert('用户名或密码不正确！');history.go(-1);</script>");
	 }	 
}elseif(isset($_GET['logout'])){
	unset ($_SESSION['dlid']);
	exit("<script>alert('您已成功注销本次登陆！');window.location.href='./Kyun/index.php';</script>");
}elseif($dlid<>""){
	exit("<script>alert('您已经登陆！');window.location.href='./data/index.php';</script>");
}else{ 
    exit("<script>window.location.href='./Kyun/index.php';</script>");
}		 
?>