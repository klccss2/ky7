<?php
/**
 *===================================
 * 项目：快云流控管理系统
 * 功能：显示平台所有套餐信息
 * 作者：by 飞跃 
 * 时间：2017年11月4日 22点48分
 * 版权：归快云免流所有
 *===================================
 */
 
// 加载系统配置文件
require("../../Data/system.php");

$dlid=$_SESSION['dlid'];
if($dlid<>""){
$db = db("ky_tc");
$db2 = db("ky_dl");
$rw = $db2->where(array('id'=>$dlid))->find();
?>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">


    <title>套餐管理 - 套餐列表</title>
    <meta name="keywords" content="">
    <meta name="description" content="">

    <link rel="shortcut icon" href="favicon.ico"> 
	<link href="../../assets/css/bootstrap.min.css?v=3.3.6" rel="stylesheet">
    <link href="../../assets/css/font-awesome.css" rel="stylesheet">
    <script src="../../assets/js/jquery.min.js"></script>
	<script src="../../assets/js/bootstrap.min.js"></script>
    <link href="../../assets/css/animate.css" rel="stylesheet">
    <link href="../../assets/css/style.css?v=4.1.0" rel="stylesheet">

</head>

<body class="gray-bg">
<div class="wrapper wrapper-content animated fadeInUp">
   <div class="row">
         <div class="col-sm-12">
			<div class="ibox-mulu">
      <h3> &nbsp;&nbsp; <i class="fa fa-shopping-cart fa-lg"></i> 套餐管理 > 套餐列表</h3>
              </div>
			  <br>
<?php
if($_GET['my'] == 'addkm'){
$row = $db->where(array('id'=>$_GET['tid']))->find();
$num = daddslashes(intval($_GET['num']));
$value = $row["tian"];
$values = $row["G"];
$money = round($num * $row['money'] * $rw['rebate'] / 100,2);
if($rw['money'] < $money){
   exit("<script>alert('抱歉,你的余额已不足请充值！');history.go(-1);</script>");
}else{
  echo '<div class="ibox"><div class="ibox-content"><h3>成功生成以下卡密</h3>';
  $Nowmoney = round($rw['money'] - $money,2);
  $db2->where(array('id'=>$dlid))->update(array('money'=>$Nowmoney));
  addlog("代理购买",'代理'.$rw['user']."花费".$money."元购买了套餐【".$row['name']."】".$num.'张卡密');
  for ($i = 0; $i < $num; $i++) {
  $km = getkm(18);
    if(db("ky_km")->insert(array('kind'=>'1','km'=>$km,'value'=>$value,'values'=>$values,'daili'=>$dlid,'addtime'=>$now))){
        echo ''.$km.'<br>';
    }else{
        echo '<div class="box">抱歉，添加卡密失败</div>';
    }
  }
}
exit('<hr/><a href="./kms_list.php" class="btn btn-success">返回卡密列表</a></div></div>');
}elseif($_GET['my'] == 'addqq'){
$row = $db->where(array('id'=>$_GET['tid']))->find();
$num = daddslashes(intval($_GET['num']));
$strlen = daddslashes($_GET['strlen']);
$state = daddslashes($_GET['state']);
$tian = $row["tian"];
$maxll = $row["G"] * 1024 * 1024 * 1024;
$endtime = time()+3600*24*daddslashes($row["tian"]);
$money = round($num * $row['money'] * $rw['rebate'] / 100,2);
if($rw['money'] < $money){
   exit("<script>alert('抱歉,你的余额已不足请充值！');history.go(-1);</script>");
}else{
 $Nowmoney = round($rw['money'] - $money,2);
 $db2->where(array('id'=>$dlid))->update(array('money'=>$Nowmoney));
 addlog("代理购买",'代理'.$rw['user']."花费".$money."元购买了套餐【".$row['name']."】".$num.'个账号');
 echo '<div class="ibox"><div class="ibox-content"><h3>成功生成以下账号</h3>';
 for($i = 0 ; $i < $num; $i++){
   $user = getkm($strlen);
   $pass = getkm($strlen);
   if(!db("openvpn")->where(array("iuser"=>$user))->find()){
      if(db("openvpn")->insert(array('iuser'=>$user,'pass'=>$pass,'maxll'=>$maxll,'i'=>$state,'starttime'=>time(),'endtime'=>$endtime,'dlid'=>$dlid,'tian'=>$tian)))	
          echo '账号：'.$user.'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;密码：'.$pass.'<br>';
      else 
          echo '<div class="box">抱歉，添加账号失败</div>';
   }else{
      echo '<div class="box">亲，该账号已存在</div>';
   }
 }
}
exit('<hr/><a href="./user_list.php" class="btn btn-success">返回账号列表</a></div></div>');
}else{
$taocan_list = $db->where(array('dlid'=>'0'))->order('id desc')->select();
echo '<div class="row">';
foreach($taocan_list as $res){
if($res["i"] == "1" ){
   $i='<span class="label label-primary">按时间计费</span>';
}else{
   $i='<span class="label label-success">按流量计费</span>';
}	
echo '
       <div class="col-sm-3">
         <div class="ibox">
          <div class="ibox-content">
		  <center>
	     <h2>'.$res['name'].'</h2>
		 <h3>套餐时间：'.$res['tian'].' 天</h3>
		 <h3>套餐流量：'.$res['G'].' G</h3>
		 <h3>出售金额：'.$res['money'].' 元</h3>
		 <h3>计费方式：'.$i.'</h3>
		<a class="btn btn-xs btn-primary" data-toggle="modal" data-target="#add_km" onclick="TaoCan('.$res['id'].')">购买卡密</a>
		<a class="btn btn-xs btn-success" data-toggle="modal" data-target="#add_qq" onclick="TaoCan('.$res['id'].')">购买账号</a>
	 </center></div></div></div>';
}
echo '</div>';
}
?>

    </div>
	  </div>
		 </div>
              </div>
		 </div>
<!-- 模态框（Modal） -->
<div class="modal fade" id="add_km" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">
					&times;
				</button>
				<h4 class="modal-title">
			  购买套餐卡密
			</h4>
			</div>
			<div class="modal-body">
				<div id="xinxi" class="form-group">
                  <label for="name">请输入卡密数量</label><br>
					<input id="kmnum" class="form-control" value="30" style="border-radius:6px;"/> 
				</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">
				   Close
				</button>
				<button onclick="Addkm()" class="btn btn-primary" data-dismiss="modal">
					保持内容
				</button>
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal -->
</div>
<!-- 模态框（Modal）end --> 
<!-- 模态框（Modal） -->
<div class="modal fade" id="add_qq" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">
					&times;
				</button>
				<h4 class="modal-title">
			  购买套餐账号
			</h4>
			</div>
			<div class="modal-body">
				<div class="form-group">
                  <label for="name">请输入账号数量</label><br>
					<input id="qqnum" class="form-control" value="30" style="border-radius:6px;"/> 
				</div>
				<div class="form-group">
				  <label for="name">请输入账号长度</label><br>
					<input id="strlen" class="form-control" value="8" style="border-radius:6px;"/> 
				</div>
				<div class="form-group">
				  <label for="name">账号状态</label>
                      <select class="form-control m-b" id="state">
                          <option value="1">开通</option>
						 <option value="2">未激活</option>
                    </select>
				 </div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">
				   Close
				</button>
				<button onclick="Addqq()" class="btn btn-primary" data-dismiss="modal">
					保持内容
				</button>
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal -->
</div>
<!-- 模态框（Modal）end --> 
    </body>
<script>
var tid = 0;
function TaoCan(id){
    tid = id;
}
function Addkm(){
	var nums = $("#kmnum").val();
    window.location.href='./taocan_list.php?my=addkm&num='+ nums +'&tid='+ tid;
}
function Addqq(){
	var nums = $("#qqnum").val();
	var strlen = $("#strlen").val();
	var state = $("#state").val();
    window.location.href='./taocan_list.php?my=addqq&num='+ nums +'&tid='+ tid +'&strlen='+ strlen + '&state='+ state;
}
</script>
</html>
<?php
}else{
   exit("<script>window.location.href='../index.php';</script>");
}                 
?>