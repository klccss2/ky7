<?php
/**
 *===================================
 * 项目：快云流控管理系统
 * 功能：管理加盟商所有卡密
 * 作者：by 飞跃 
 * 时间：2017年11月4日 22点48分
 * 版权：归快云免流所有
 *===================================
 */
 
// 加载系统配置文件
require("../../Data/system.php");

$dlid = $_SESSION['dlid'];
if($dlid<>""){
$db = db("ky_km");
?>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">


    <title>加盟商后台 - 卡密列表</title>
    <meta name="keywords" content="">
    <meta name="description" content="">

    <link rel="shortcut icon" href="../favicon.ico"> 
	<link href="../../assets/css/bootstrap.min.css?v=3.3.6" rel="stylesheet">
    <link href="../../assets/css/font-awesome.css" rel="stylesheet">

    <link href="../../assets/css/animate.css" rel="stylesheet">
    <link href="../../assets/css/style.css?v=4.1.0" rel="stylesheet">
</head>

<body class="gray-bg">
<div class="wrapper wrapper-content animated fadeInUp">
<div class="row">
<div class="col-sm-12">
			<div class="ibox-mulu">
      <h3> &nbsp;&nbsp; <i class="fa fa-book fa-lg"></i> 卡密管理 > 卡密列表</h3>
              </div>
			  <br>
<?php
if(isset($_GET['my'])){
$my = $_GET['my'];
if($my == 'del'){
  if($db->where(array('id'=>$_GET['id']))->delete()){
     echo Skip('删除卡密',success);
  }else{
     echo Skip('删除卡密',error);
 }
}elseif($my == 'sy'){//删除卡密结果
if($db->where(array('daili'=>$dlid,'isuse'=>'1'))->delete()){
     echo Skip('删除已使用卡密',success);
  }else{
     echo Skip('删除已使用卡密',error);
  }
}
exit;
}elseif(isset($_GET['cha'])){
	$numrows = $db->where(array('daili'=>$dlid,'kind'=>'1','km'=>$_GET['cha']))->getnums();
}else{
	$numrows = $db->where(array('daili'=>$dlid,'kind'=>'1'))->getnums();
}
echo '<div class="ibox"><div class="ibox-content">
     <form> <button type="submit" class="btn btn-primary">卡密管理</button>
   <a href="#" class="btn btn-info">平台共有 <b>'.$numrows.'</b> 个卡密</a>
  <a href="kms_list.php?my=sy" class="btn btn-danger" onclick="return confirm(\'你确实要进行操作吗？\');">删除已使用卡密</a>
  </form>';
?>
  <div class="table-responsive">
         <table class="table table-bordered table-hover">
       <thead><tr><th class="text-center">卡密</th><th class="text-center">信息</th><th class="text-center">状态</th><th class="text-center">套餐时间</th><th class="text-center">套餐流量</th><th class="text-center">使用者</th><th class="text-center">添加时间</th><th class="text-center">使用时间</th><th class="text-center">操作</th></tr></thead>
          <tbody>
<?php
$pagesize=50;
$pages=intval($numrows/$pagesize);
if ($numrows%$pagesize)
{
 $pages++;
 }
if (isset($_GET['page'])){
$page=intval($_GET['page']);
}else{
$page=1;
}
$offset=$pagesize*($page - 1);
if(isset($_GET['cha'])){
    $kms_list = $db->where(array('daili'=>$dlid,'kind'=>'1','km'=>$_GET['cha']))->order('id desc')->limit($offset,$pagesize)->select();
}else{
	$kms_list = $db->where(array('daili'=>$dlid,'kind'=>'1'))->order('id desc')->limit($offset,$pagesize)->select();
}
foreach($kms_list as $res){
if($res['isuse']==1) {
	$isuse='<span class="label label-danger">已使用</span>';
} elseif($res['isuse']==0) {
	$isuse='<span class="label label-primary">正常</span>';
}
if($res['usetime']==NULL){
$usetime='—';
}else{
$usetime=$res['usetime'];	
}
if($res['user']==NULL){
  $user='—';
}else{
  $user='<span class="label label-warning">'.$res['user'].'</span>';
}
echo '<tr><td class="text-center">'.$res['id'].'</td>
<td class="text-center">'.$res['km'].'</td>
<td class="text-center">'.$isuse.'</td>
<td class="text-center">'.$res['value'].'</td>
<td class="text-center">'.$res['values'].' G</td>
<th class="text-center">'.$user.'</th>
<td class="text-center">'.$res['addtime'].'</td>
<td class="text-center">'.$usetime.'</td>
<td class="text-center"><a href="./kms_list.php?my=del&id='.$res['id'].'" class="btn btn-xs btn-danger" onclick="return confirm(\'你确实要删除此卡密吗？\');">删除</a></td></tr>';
}
?>
          </tbody>
        </table>
      </div>
<?php
echo'<ul class="pagination">';
$first=1;
$prev=$page-1;
$next=$page+1;
$last=$pages;
if ($page>1)
{
echo '<li><a href="kms_list.php?page='.$first.$link.'">首页</a></li>';
echo '<li><a href="kms_list.php?page='.$prev.$link.'">&laquo;</a></li>';
} else {
echo '<li class="disabled"><a>首页</a></li>';
echo '<li class="disabled"><a>&laquo;</a></li>';
}
for ($i=1;$i<$page;$i++)
echo '<li><a href="kms_list.php?page='.$i.$link.'">'.$i .'</a></li>';
echo '<li class="disabled"><a>'.$page.'</a></li>';
for ($i=$page+1;$i<=$pages;$i++)
echo '<li><a href="kms_list.php?page='.$i.$link.'">'.$i .'</a></li>';
echo '';
if ($page<$pages)
{
echo '<li><a href="kms_list.php?page='.$next.$link.'">&raquo;</a></li>';
echo '<li><a href="kms_list.php?page='.$last.$link.'">尾页</a></li>';
} else {
echo '<li class="disabled"><a>&raquo;</a></li>';
echo '<li class="disabled"><a>尾页</a></li>';
}
echo'</ul>';
#分页
?>
    </div>
		</div>
          </div>
          </div>
         </div>
    </body>
</html>
<?php
}else{ 
    exit("<script language='javascript'>window.location.href='../index.php';</script>");
}
?>