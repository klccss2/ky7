<?php
echo '<title>404</title>
<center>
<img src="http://'.$_SERVER['SERVER_NAME'].':'.$_SERVER["SERVER_PORT"].'/assets/img/404.png" width="60%" height="60%"/>
</center>';
