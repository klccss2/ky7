#!/bin/bash
#负载集群请直接使用官网脚本

php /kyun/wwwroot/Data/user_out.php "$common_name" "$bytes_received" "$bytes_sent"